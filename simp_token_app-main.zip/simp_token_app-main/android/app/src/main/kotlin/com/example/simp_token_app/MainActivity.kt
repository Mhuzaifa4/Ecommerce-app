package com.example.simp_token_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
