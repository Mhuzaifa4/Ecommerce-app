import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:simp_token_app/admin/orders.dart';
import 'package:simp_token_app/admin/returns&Refund.dart';
import 'package:simp_token_app/admin/uploadProduct.dart';
import 'package:simp_token_app/admin/viewproducts.dart';
import 'package:simp_token_app/customwidgets/reusable_btn.dart';
import 'package:simp_token_app/pages/login_page.dart';
import 'package:simp_token_app/utils/theme.dart';
import 'package:simp_token_app/auth/auth_service.dart';

class AdminScreen extends StatefulWidget {
  const AdminScreen({Key? key}) : super(key: key);

  @override
  State<AdminScreen> createState() => _AdminScreenState();
}

class _AdminScreenState extends State<AdminScreen> {
  int userCount = 0;
  int OrderCount = 0;
  int productsCount = 0;
  int pendingOrderCount = 0;
  late Timer _timer;

  @override
  void initState() {
    super.initState();
    _fetchData(); // Initial fetch
    _timer = Timer.periodic(Duration(seconds: 1), (Timer t) => _fetchData());
  }

  @override
  void dispose() {
    super.dispose();
    _timer.cancel(); // Cancel the timer to prevent memory leaks
  }

  void _fetchData() {
    _fetchUserCount();
    _fetchOrdersCount();
    _fetcProductsCount();
    _fetchPendingOrdersCount();
  }

  Future<void> _fetchOrdersCount() async {
    try {
      QuerySnapshot usersSnapshot =
          await FirebaseFirestore.instance.collection('Order').get();
      setState(() {
        OrderCount = usersSnapshot.size;
      });
    } catch (e) {
      print('Error fetching user count: $e');
    }
  }

  Future<void> _fetchPendingOrdersCount() async {
    try {
      QuerySnapshot ordersSnapshot = await FirebaseFirestore.instance
          .collection('Order')
          .where('orderStatus', isEqualTo: 'Pending')
          .get();
      setState(() {
        pendingOrderCount = ordersSnapshot.size;
      });
    } catch (e) {
      print('Error fetching pending orders count: $e');
    }
  }

  Future<void> _fetchUserCount() async {
    try {
      QuerySnapshot usersSnapshot =
          await FirebaseFirestore.instance.collection('User').get();
      setState(() {
        userCount = usersSnapshot.size;
      });
    } catch (e) {
      print('Error fetching user count: $e');
    }
  }

  Future<void> _fetcProductsCount() async {
    try {
      QuerySnapshot usersSnapshot =
          await FirebaseFirestore.instance.collection('Products').get();
      setState(() {
        productsCount = usersSnapshot.size;
      });
    } catch (e) {
      print('Error fetching user count: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: SimpTokenColorTheme().primaryColor,
        automaticallyImplyLeading: false,
        title: Text(
          'Dashboard',
          style: TextStyle(
              color: SimpTokenColorTheme().white,
              fontSize: 20,
              fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Container(
              height: 100,
              width: double.maxFinite,
              padding: EdgeInsets.all(10),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                color: Colors.blue,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    'Total Users:',
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Text(
                    '  $userCount',
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(
              height: 10,
            ),
            Row(
              children: [
                Flexible(
                  child: GestureDetector(
                    onTap: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) =>
                                  OrdersView(type: "All Orders")));
                    },
                    child: Container(
                      height: 100,
                      width: double.maxFinite,
                      padding: EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(12),
                        color: Colors.purple,
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            'Number of Orders:',
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          Text(
                            ' $OrderCount',
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  width: 10,
                ),
                Flexible(
                  child: GestureDetector(
                    onTap: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) =>
                                  OrdersView(type: "Pending Orders")));
                    },
                    child: Container(
                      height: 100,
                      width: double.maxFinite,
                      padding: EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(12),
                        color: Colors.red,
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            'Pending Orders:',
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          Text(
                            pendingOrderCount.toString(),
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(
              height: 10,
            ),
            Flexible(
                child: Container(
              height: 100,
              width: double.maxFinite,
              padding: EdgeInsets.all(10),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                color: Colors.amber,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    'Number of Products:',
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Text(
                    ' $productsCount',
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            )),
            SizedBox(
              height: 40,
            ),
              ReUsableButton(
              title: "Return & Refund management",
              onTap: () {
                Navigator.push(context,
                    MaterialPageRoute(builder: (context) => ReturnRefunds()));
              },
            ),
            SizedBox(height: 20),
            ReUsableButton(
              title: "View Products",
              onTap: () {
                Navigator.push(context,
                    MaterialPageRoute(builder: (context) => ViewProducts()));
              },
            ),
            SizedBox(height: 20),
            ReUsableButton(
              title: "Upload Products",
              onTap: () {
                Navigator.push(context,
                    MaterialPageRoute(builder: (context) => AdminPanel()));
              },
            ),
 SizedBox(height: 20),
             ReUsableButton(
              title: " Log out",
              onTap: () {
                 Navigator.pushReplacement(
  context,
  MaterialPageRoute(
    builder: (BuildContext context) => LoginPage(),
  ),
);

              },
            ),
            SizedBox(height: 20),
          ],
        ),
      ),
    );
  }
}
