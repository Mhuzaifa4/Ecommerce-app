import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:simp_token_app/models/product_model.dart';

class EditProduct extends StatefulWidget {
  final ProductModel productModel;

  const EditProduct({Key? key, required this.productModel}) : super(key: key);

  @override
  _EditProductState createState() => _EditProductState();
}

class _EditProductState extends State<EditProduct> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  TextEditingController productNameController = TextEditingController();
  TextEditingController categoryController = TextEditingController();
  TextEditingController shortdescriptionController = TextEditingController();
  TextEditingController longdescriptionController = TextEditingController();
  TextEditingController priceController = TextEditingController();
  TextEditingController stockController = TextEditingController();
  TextEditingController discountController = TextEditingController();
  TextEditingController thumbnailimageTitleController = TextEditingController();
  TextEditingController additionalImageModelsController =
      TextEditingController();
  TextEditingController availableController = TextEditingController();
  TextEditingController featuredController = TextEditingController();
  TextEditingController avgRatingController = TextEditingController();

  TextEditingController productCountController = TextEditingController();
  bool _updatingProduct = false;
  @override
  void initState() {
    super.initState();

    productNameController.text = widget.productModel.productName;
    longdescriptionController.text = widget.productModel.longDescription!;
    shortdescriptionController.text = widget.productModel.shortDescription!;
    thumbnailimageTitleController.text =
        widget.productModel.thumbnailImageModel.title;
    priceController.text = widget.productModel.salePrice.toString();
    stockController.text = widget.productModel.stock.toString();
  }

  void EditProductInFirestore() async {
    setState(() {
      _updatingProduct = true; // Set the flag to true when update starts
    });
    try {
      // Access the Firestore instance
      FirebaseFirestore firestore = FirebaseFirestore.instance;

      // Specify the collection and document path
      String collectionPath = 'Products';

      // Document ID of the product to be updated
      String? productId = widget.productModel.productId;

      // Create a map with updated product details
      Map<String, dynamic> updatedProductData = {
        'productName': productNameController.text,
        'longDescription': longdescriptionController.text,
        'shortDescription': shortdescriptionController.text,
        'productCount': int.parse(productCountController.text),
        'thumbnailImageModel': {
          'title': thumbnailimageTitleController.text,
          'imageDownloadUrl':
              widget.productModel.thumbnailImageModel.imageDownloadUrl,
        },
        'salePrice': double.parse(priceController.text),
        'stock': int.parse(stockController.text),
      };

      // Update the existing document in Firestore
      await firestore
          .collection(collectionPath)
          .doc(productId)
          .update(updatedProductData);

      print('Product data updated successfully!');
    } catch (error) {
      print('Error updating product data: $error');
    }
  }

  Future<void> deleteProductInFirestore(BuildContext context) async {
    try {
      // Access the Firestore instance
      FirebaseFirestore firestore = FirebaseFirestore.instance;

      // Specify the collection and document path
      String collectionPath = 'Products';

      // Ensure productId is not null
      if (widget.productModel.productId != null) {
        // Document ID of the product to be deleted
        String productId = widget.productModel.productId!;

        // Delete the document from Firestore
        await firestore.collection(collectionPath).doc(productId).delete();

        print('Product deleted successfully!');

        // Show a Snackbar indicating successful deletion
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Product deleted successfully!'),
            duration: Duration(seconds: 2),
          ),
        );

        Navigator.of(context)
            .pop(); // Close the current screen or navigate back
      } else {
        print('Error: ProductId is null');
      }
    } catch (error) {
      print('Error deleting product: $error');

      // Show a Snackbar indicating an error
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error deleting product'),
          duration: Duration(seconds: 2),
        ),
      );
    }
  }

  Future<void> showDeleteConfirmationDialog(BuildContext context) async {
    return showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Confirm Deletion'),
          content: Text('Do you really want to delete the product?'),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.of(context).pop(); // Close the dialog
              },
              child: Text('No'),
            ),
            TextButton(
              onPressed: () async {
                await deleteProductInFirestore(context);
                Navigator.of(context).pop(); // Close the dialog
              },
              child: Text('Yes'),
            ),
          ],
        );
      },
    );
  }

  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text('Update Product'),
        ),
        body: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Form(
            key: _formKey,
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  TextFormField(
                    controller: productNameController,
                    decoration: InputDecoration(
                      labelText: 'Product Name',
                      border: OutlineInputBorder(),
                      // Add more customization options as needed
                    ),
                    validator: (value) {
                      if (value!.isEmpty) {
                        return 'Please enter a product name';
                      }
                      return null;
                    },
                  ),
                  SizedBox(height: 10),
                  TextFormField(
                    controller: longdescriptionController,
                    decoration: InputDecoration(
                      labelText: 'Product Long Description',
                      border: OutlineInputBorder(),
                      // Add more customization options as needed
                    ),
                    validator: (value) {
                      if (value!.isEmpty) {
                        return 'Please enter a description';
                      }
                      return null;
                    },
                  ),
                  SizedBox(height: 10),
                  TextFormField(
                    controller: shortdescriptionController,
                    decoration: InputDecoration(
                      labelText: 'Product Short Description',
                      border: OutlineInputBorder(),
                      // Add more customization options as needed
                    ),
                    validator: (value) {
                      if (value!.isEmpty) {
                        return 'Please enter a description';
                      }
                      return null;
                    },
                  ),

                  SizedBox(height: 10),
                  TextFormField(
                    controller: priceController,
                    decoration: InputDecoration(
                      labelText: 'Product Sale Price',
                      border: OutlineInputBorder(),
                      // Add more customization options as needed
                    ),
                    keyboardType: TextInputType.number,
                    validator: (value) {
                      if (value!.isEmpty) {
                        return 'Please enter a price';
                      }
                      return null;
                    },
                  ),
                  SizedBox(height: 10),
                  TextFormField(
                    controller: stockController,
                    decoration: InputDecoration(
                      labelText: 'Stock',
                      border: OutlineInputBorder(),
                      // Add more customization options as needed
                    ),
                    keyboardType: TextInputType.number,
                    validator: (value) {
                      if (value!.isEmpty) {
                        return 'Please enter stock quantity';
                      }
                      return null;
                    },
                  ),
                  // Inside your widget's build method or as a class member

                  SizedBox(height: 10),
                  TextFormField(
                    controller: productCountController,
                    decoration: InputDecoration(
                      labelText: 'Product Count',
                      border: OutlineInputBorder(),
                      // Add more customization options as needed
                    ),
                    keyboardType: TextInputType.number,
                    validator: (value) {
                      if (value!.isEmpty) {
                        return 'Please enter a product count';
                      }
                      return null;
                    },
                  ),

                  SizedBox(height: 10),

                  TextFormField(
                    controller: thumbnailimageTitleController,
                    decoration: InputDecoration(
                      labelText: 'title  ',
                      border: OutlineInputBorder(),
                      // Add more customization options as needed
                    ),
                    validator: (value) {
                      if (value!.isEmpty) {
                        return 'Please enter a product image title';
                      }
                      return null;
                    },
                  ),
                  SizedBox(height: 20),
                  ElevatedButton(
                    onPressed: () {
                      EditProductInFirestore();
                    },
                    child: Text('Update Product'),
                    style: ElevatedButton.styleFrom(
                      primary:
                          Colors.black, // Set the background color to black
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10.0),
                        // Set border radius if needed
                      ),
                    ),
                  ),
                  ElevatedButton(
                    onPressed: () {
                      showDeleteConfirmationDialog(context);
                    },
                    child: Text('Delete Product'),
                    style: ElevatedButton.styleFrom(
                      primary: Colors.red,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10.0),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ));
  }
}
