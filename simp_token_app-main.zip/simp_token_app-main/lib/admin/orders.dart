import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:simp_token_app/models/order_model.dart';
import 'package:simp_token_app/utils/theme.dart';

class OrdersView extends StatelessWidget {
  final String type;

  OrdersView({Key? key, required this.type}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: SimpTokenColorTheme().primaryColor,
        title: Text(
          'Orders',
          style: TextStyle(
            color: SimpTokenColorTheme().white,
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),
        ),
        centerTitle: true,
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance.collection('Order').snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(
              child: CircularProgressIndicator(),
            );
          } else if (snapshot.hasError) {
            return Center(
              child: Text('Error loading orders: ${snapshot.error}'),
            );
          } else if (snapshot.data == null || snapshot.data!.docs.isEmpty) {
            return Center(
              child: Text('No orders available.'),
            );
          } else {
            // Filter orders based on the type
            List<OrderModel> filteredOrders = [];
            if (type == "All Orders") {
              filteredOrders = snapshot.data!.docs
                  .map((orderData) => OrderModel.fromMap(
                      orderData.data() as Map<String, dynamic>))
                  .toList();
            } else if (type == "Pending Orders") {
              filteredOrders = snapshot.data!.docs
                  .map((orderData) => OrderModel.fromMap(
                      orderData.data() as Map<String, dynamic>))
                  .where(
                      (order) => order.orderStatus.toLowerCase() == 'pending')
                  .toList();
            }

            return ListView.builder(
              itemCount: filteredOrders.length,
              itemBuilder: (context, index) {
                var orderModel = filteredOrders[index];
                return OrderListItems(orderModel: orderModel, type: type);
              },
            );
          }
        },
      ),
    );
  }
}

class OrderListItems extends StatelessWidget {
  final OrderModel orderModel;
  final String type;

  const OrderListItems({required this.orderModel, required this.type, Key? key})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    print('Order Id: ${orderModel.orderId}');

    void showProductApprovalDialog(String productName) {
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text('Approve Product'),
            content: Text('Do you want to approve the product $productName?'),
            actions: [
              TextButton(
                onPressed: () {
                  orderModel.updateOrderStatus('Delivered');
                  Navigator.pop(context);
                },
                child: Text('Delivered'),
              ),
              TextButton(
                onPressed: () {
                  orderModel.updateOrderStatus('Cancelled');
                  Navigator.pop(context);
                },
                child: Text('Reject'),
              ),
            ],
          );
        },
      );
    }

    return Card(
      margin: EdgeInsets.symmetric(vertical: 8, horizontal: 16),
      child: ListTile(
        contentPadding: EdgeInsets.all(16),
        title: Text('Order ID: ${orderModel.orderId}'),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Display Delivery Address Details
            Text('Delivery Address:'),
            Text('Address Line 1: ${orderModel.deliveryAddress['addressLine1']}'),
            Text('Address Line 2: ${orderModel.deliveryAddress['addressLine2']}'),
            Text('City: ${orderModel.deliveryAddress['city']}'),
            Text('Zipcode: ${orderModel.deliveryAddress['zipcode']}'),
            SizedBox(height: 16), // Adjust the spacing

            // Display Product Details
            ...orderModel.productDetails.map((product) => Padding(
                  padding: const EdgeInsets.only(bottom: 8.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(product.productName ?? ""),
                      Text("Price: ${product.salePrice.toString()}" ?? ""),
                      Row(
                        children: [
                          ClipRRect(
                            borderRadius: BorderRadius.circular(8),
                            child: Image.network(
                              product.productImageUrl ?? "",
                              width: 100,
                              height: 100,
                              fit: BoxFit.cover,
                            ),
                          ),
                          Spacer(),
                          Text(orderModel.orderStatus ?? ""),
                        ],
                      ),
                      SizedBox(height: 8),
                    ],
                  ),
                )),
          ],
        ),
        onTap: () {
          if (type == "Pending Orders") {
            showProductApprovalDialog(
                orderModel.productDetails[0].productName ?? "");
          }
        },
      ),
    );
  }
}
