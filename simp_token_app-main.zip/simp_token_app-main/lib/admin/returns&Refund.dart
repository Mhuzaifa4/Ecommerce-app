import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
class ReturnRefunds extends StatelessWidget {
  const ReturnRefunds({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Returns and Refunds'),
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance.collection('Refund').snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(
              child: CircularProgressIndicator(),
            );
          } else if (snapshot.hasError) {
            return Center(
              child: Text('Error: ${snapshot.error}'),
            );
          } else if (snapshot.data == null || snapshot.data!.docs.isEmpty) {
            return Center(
              child: Text('No returns or refunds available.'),
            );
          } else {
            return ListView.builder(
              itemCount: snapshot.data!.docs.length,
              itemBuilder: (context, index) {
                var returnData =
                    snapshot.data!.docs[index].data() as Map<String, dynamic>;

                return ListTile(
                  title: Text('Order ID: ${returnData['orderId']}'),
                  subtitle: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Product Name: ${returnData['productName']}'),
                      Text('Reason: ${returnData['reason']}'),
                      Text('Bank Name: ${returnData['bankName']}'),
                      Text('Beneficiary Name: ${returnData['beneficiaryName']}'),
                    ],
                  ),
                  leading: Image.network(
                    returnData['image'],
                    width: 50,
                    height: 50,
                    fit: BoxFit.cover,
                  ),
                  onTap: () {
                    showDialog(
                      context: context,
                      builder: (context) => AlertDialog(
                        title: Text('Accept or Reject?'),
                        actions: <Widget>[
                          TextButton(
                            onPressed: () {
                              // Accept the return
                              FirebaseFirestore.instance
                                  .collection('Order')
                                  .doc(returnData['orderId'])
                                  .update({'orderStatus': 'Return Request Accepted.'});
                              Navigator.pop(context);
                            },
                            child: Text('Accept'),
                          ),
                          TextButton(
                            onPressed: () {
                              FirebaseFirestore.instance
                                  .collection('Order')
                                  .doc(returnData['orderId'])
                                  .update({'orderStatus': 'Return Request Rejected.'});
                              Navigator.pop(context);
                            },
                            child: Text('Reject'),
                          ),
                        ],
                      ),
                    );
                  },
                );
              },
            );
          }
        },
      ),
    );
  }
}
