import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:image_picker/image_picker.dart';
import 'package:simp_token_app/customwidgets/reusable_btn.dart';
import 'package:simp_token_app/utils/theme.dart';

class AdminPanel extends StatefulWidget {
  const AdminPanel({Key? key}) : super(key: key);

  @override
  _AdminPanelState createState() => _AdminPanelState();
}

class _AdminPanelState extends State<AdminPanel> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  TextEditingController productNameController = TextEditingController();
  TextEditingController longdescriptionController = TextEditingController();
  TextEditingController shortdescriptionController = TextEditingController();
  TextEditingController productCountController = TextEditingController();
  TextEditingController thumbnailimageTitleController = TextEditingController();

  String? selectedCategory;
  Map<String, String> categoryIds = {
    'Women': 'LOnilAbHAYnyaLDqGTBA',
    'Children': 'fJ6r4zUGywdDLETjFXsq',
    'Men': 'zO1w56B2VzYskI0ie5Oq',
  };
  List<XFile?> additionalImages = List.generate(2, (index) => null);
  XFile? thumbnailImage;

  Future<void> _pickImage(int index) async {
    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(source: ImageSource.gallery);

    setState(() {
      if (index == 3) {
        // This is the thumbnail image
        thumbnailImage = pickedFile;
      } else {
        // These are additional images
        additionalImages[index - 1] = pickedFile;
      }
    });
  }

  TextEditingController priceController = TextEditingController();
  TextEditingController stockController = TextEditingController();

  void _submitForm() async {
    showDialog(
      context: context,
      barrierDismissible: false, // Prevent user from dismissing the dialog
      builder: (BuildContext context) {
        return Center(
          child: CircularProgressIndicator(),
        );
      },
    );

    if (_formKey.currentState!.validate()) {
      if (selectedCategory == null) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Please select a category'),
          ),
        );
        return;
      }

      if (additionalImages.every((image) => image == null)) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Please select at least one additional image'),
          ),
        );
        return;
      }

      if (thumbnailImage == null) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Please select a thumbnail image'),
          ),
        );
        return;
      }

      // Upload additional images and get their download URLs
      List<String?> additionalImageUrls = await uploadAdditionalImages();

      // Upload the thumbnail image and get its URL
      String thumbnailUrl = await uploadThumbnailToStorage(thumbnailImage!);

      // Access the Firestore instance
      FirebaseFirestore firestore = FirebaseFirestore.instance;

      // Specify the collection path
      String collectionPath = 'Products';

      // Use the `add` method to let Firestore generate a document ID
      DocumentReference docRef =
          await firestore.collection(collectionPath).add({
        'avgRating': 0,
        'productAdditionalImages': additionalImageUrls,
        'productAvailable': true,
        'productCategory': {
          'categoryId': categoryIds[selectedCategory!],
          'categoryName': selectedCategory,
          'productCount': int.parse(productCountController.text),
        },
        'productDiscount': 0,
        'productFeatured': false,
        'productId': null,
        'productLongDescription': longdescriptionController.text,
        'productName': productNameController.text,
        'productSalePrice': double.parse(priceController.text),
        'productShortDescription': shortdescriptionController.text,
        'productStock': int.parse(stockController.text),
        'productThumbnailImageUrl': {
          'imageDownloadUrl': thumbnailUrl,
          'productId': null,
          'title': thumbnailimageTitleController.text,
        },
      });

      // Get the auto-generated ID
      String productId = docRef.id;

      // Modify the productData to include the productId
      Map<String, dynamic> productData = {
        'avgRating': 0,
        'productAdditionalImages': additionalImageUrls,
        'productAvailable': true,
        'productCategory': {
          'categoryId': categoryIds[selectedCategory!],
          'categoryName': selectedCategory,
          'productCount': int.parse(productCountController.text),
        },
        'productDiscount': 0,
        'productFeatured': false,
        'productId': productId,
        'productLongDescription': longdescriptionController.text,
        'productName': productNameController.text,
        'productSalePrice': double.parse(priceController.text),
        'productShortDescription': shortdescriptionController.text,
        'productStock': int.parse(stockController.text),
        'productThumbnailImageUrl': {
          'imageDownloadUrl': thumbnailUrl,
          'productId': productId,
          'title': thumbnailimageTitleController.text,
        },
      };

      // Update the document with the modified productData
      await docRef.update(productData);

      // Clear form fields and reset state
      clearFormFields();
      setState(() {
        selectedCategory = null;
        additionalImages = List.generate(3, (index) => null);
        thumbnailImage = null;
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Product uploaded successfully'),
        ),
      );
      Navigator.pop(context);
      Navigator.pop(context);
    }
  }

  Future<List<String?>> uploadAdditionalImages() async {
    List<String?> additionalImageUrls = [];

    for (int i = 0; i < additionalImages.length; i++) {
      if (additionalImages[i] != null) {
        String imageUrl = await uploadImageToStorage(additionalImages[i]!);
        additionalImageUrls.add(imageUrl);
      } else {
        additionalImageUrls.add(null);
      }
    }

    return additionalImageUrls;
  }

  Future<String> uploadImageToStorage(XFile imageFile) async {
    // Ensure that Firebase is initialized
    await Firebase.initializeApp();

    // Create a unique filename for the image
    String fileName = DateTime.now().millisecondsSinceEpoch.toString();

    // Reference to the Firebase Storage bucket with the folder path
    Reference storageReference =
        FirebaseStorage.instance.ref().child('ProductImages/$fileName');

    // Upload the image
    UploadTask uploadTask = storageReference.putFile(File(imageFile.path));

    // Get the download URL once the upload is complete
    TaskSnapshot taskSnapshot = await uploadTask;
    String imageUrl = await taskSnapshot.ref.getDownloadURL();

    return imageUrl;
  }

  Future<String> uploadThumbnailToStorage(XFile imageFile) async {
    // Ensure that Firebase is initialized
    await Firebase.initializeApp();

    // Create a unique filename for the thumbnail image
    String fileName = DateTime.now().millisecondsSinceEpoch.toString();

    // Reference to the Firebase Storage bucket with the folder path
    Reference storageReference =
        FirebaseStorage.instance.ref().child('ProductImages/$fileName');

    // Upload the thumbnail image
    UploadTask uploadTask = storageReference.putFile(File(imageFile.path));

    // Get the download URL once the upload is complete
    TaskSnapshot taskSnapshot = await uploadTask;
    String thumbnailUrl = await taskSnapshot.ref.getDownloadURL();

    return thumbnailUrl;
  }

  void clearFormFields() {
    productNameController.clear();
    longdescriptionController.clear();
    shortdescriptionController.clear();
    priceController.clear();
    stockController.clear();
    productCountController.clear();
    thumbnailimageTitleController.clear();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: SimpTokenColorTheme().primaryColor,
        title: Text(
          'Upload Product',
          style: TextStyle(
              color: SimpTokenColorTheme().white,
              fontSize: 20,
              fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                TextFormField(
                  controller: productNameController,
                  decoration: InputDecoration(
                    labelText: 'Product Name',
                    border: OutlineInputBorder(),
                  ),
                  validator: (value) {
                    if (value!.isEmpty) {
                      return 'Please enter a product name';
                    }
                    return null;
                  },
                ),
                SizedBox(height: 10),
                TextFormField(
                  controller: longdescriptionController,
                  decoration: InputDecoration(
                    labelText: 'Product Long Description',
                    border: OutlineInputBorder(),
                  ),
                  validator: (value) {
                    if (value!.isEmpty) {
                      return 'Please enter a description';
                    }
                    return null;
                  },
                ),
                SizedBox(height: 10),
                TextFormField(
                  controller: shortdescriptionController,
                  decoration: InputDecoration(
                    labelText: 'Product Short Description',
                    border: OutlineInputBorder(),
                  ),
                  validator: (value) {
                    if (value!.isEmpty) {
                      return 'Please enter a description';
                    }
                    return null;
                  },
                ),
                SizedBox(height: 10),
                TextFormField(
                  controller: priceController,
                  decoration: InputDecoration(
                    labelText: 'Product Sale Price',
                    border: OutlineInputBorder(),
                  ),
                  keyboardType: TextInputType.number,
                  validator: (value) {
                    if (value!.isEmpty) {
                      return 'Please enter a price';
                    }
                    return null;
                  },
                ),
                SizedBox(height: 10),
                TextFormField(
                  controller: stockController,
                  decoration: InputDecoration(
                    labelText: 'Stock',
                    border: OutlineInputBorder(),
                  ),
                  keyboardType: TextInputType.number,
                  validator: (value) {
                    if (value!.isEmpty) {
                      return 'Please enter stock quantity';
                    }
                    return null;
                  },
                ),
                SizedBox(height: 10),
                // Inside your widget's build method or as a class member
                DropdownButtonFormField<String>(
                  value: selectedCategory,
                  onChanged: (String? value) {
                    setState(() {
                      selectedCategory = value!;
                    });
                  },
                  items: categoryIds.keys.map((String category) {
                    return DropdownMenuItem<String>(
                      value: category,
                      child: Text(category),
                    );
                  }).toList(),
                  decoration: InputDecoration(
                    labelText: 'Category',
                    border: OutlineInputBorder(),
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please select a category';
                    }
                    return null;
                  },
                ),
                SizedBox(height: 10),
                TextFormField(
                  controller: productCountController,
                  decoration: InputDecoration(
                    labelText: 'Product Count',
                    border: OutlineInputBorder(),
                  ),
                  keyboardType: TextInputType.number,
                  validator: (value) {
                    if (value!.isEmpty) {
                      return 'Please enter a product count';
                    }
                    return null;
                  },
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    for (int i = 1; i <= 2; i++)
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          ElevatedButton(
                            onPressed: () => _pickImage(i),
                            child: Text('Pick Additional Image $i'),
                          ),
                          if (additionalImages[i - 1] != null)
                            Image.file(
                              File(additionalImages[i - 1]!.path),
                              height: 100,
                              width: 100,
                            ),
                          if (additionalImages[i - 1] == null)
                            Container(
                              height: 100,
                              width: 100,
                              color: Colors.grey.shade200,
                              child: Center(
                                child: Text('Image $i not selected'),
                              ),
                            ),
                        ],
                      ),
                  ],
                ),
                SizedBox(height: 20),
                ElevatedButton(
                  onPressed: () => _pickImage(3),
                  child: Text('Pick Thumbnail Image'),
                ),
                if (thumbnailImage != null)
                  Image.file(
                    File(thumbnailImage!.path),
                    height: 100,
                    width: 100,
                  ),
                TextFormField(
                  controller: thumbnailimageTitleController,
                  decoration: InputDecoration(
                    labelStyle: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 18,
                        color: Colors.black),
                    labelText: 'Title',
                    border: OutlineInputBorder(),
                  ),
                  validator: (value) {
                    if (value!.isEmpty) {
                      return 'Please enter a product image title';
                    }
                    return null;
                  },
                ),
                SizedBox(height: 20),
                ReUsableButton(
                  title: "Upload Products",
                  onTap: () {
                    _submitForm();
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Future<void> uploadProductToFirestore(
      Map<String, dynamic> productData) async {
    try {
      EasyLoading();
      // Access the Firestore instance
      FirebaseFirestore firestore = FirebaseFirestore.instance;

      // Specify the collection path
      String collectionPath = 'Products';

      // Use the `add` method to let Firestore generate a document ID
      DocumentReference docRef =
          await firestore.collection(collectionPath).add(productData);

      // Get the auto-generated ID
      String productId = docRef.id;

      // Modify the productData to include the productId
      productData['productId'] = productId;

      // Update the document with the modified productData
      await docRef.update(productData);
      EasyLoading.dismiss();

      print('Product data uploaded to Firestore successfully!');
    } catch (error) {
      EasyLoading.dismiss();

      print('Error uploading product data to Firestore: $error');
    }
  }
}
