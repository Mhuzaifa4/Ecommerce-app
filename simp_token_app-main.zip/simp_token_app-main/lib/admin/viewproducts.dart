import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:simp_token_app/admin/editproduct.dart';
import 'package:simp_token_app/models/product_model.dart';
import 'package:simp_token_app/utils/theme.dart';

class ViewProducts extends StatefulWidget {
  const ViewProducts({Key? key}) : super(key: key);

  @override
  _ViewProductsState createState() => _ViewProductsState();
}

class _ViewProductsState extends State<ViewProducts> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: SimpTokenColorTheme().primaryColor,
        title: Text(
          'All Products',
          style: TextStyle(
              color: SimpTokenColorTheme().white,
              fontSize: 20,
              fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance.collection('Products').snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(
              child: CircularProgressIndicator(),
            );
          } else if (snapshot.hasError) {
            return Center(
              child: Text('Error: ${snapshot.error}'),
            );
          } else if (snapshot.data == null || snapshot.data!.docs.isEmpty) {
            return Center(
              child: Text('No products available.'),
            );
          } else {
            return ListView.builder(
              itemCount: snapshot.data!.docs.length,
              itemBuilder: (context, index) {
                var productData =
                    snapshot.data!.docs[index].data() as Map<String, dynamic>;
                var productModel = ProductModel.fromMap(productData);

                return ProductListItem(productModel: productModel);
              },
            );
          }
        },
      ),
    );
  }
}

class ProductListItem extends StatelessWidget {
  final ProductModel productModel;

  const ProductListItem({required this.productModel, Key? key})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    print('Product Name: ${productModel.productName}');
    print(
        'Thumbnail URL: ${productModel.thumbnailImageModel?.imageDownloadUrl}');

    return Card(
      margin: EdgeInsets.symmetric(vertical: 8, horizontal: 16),
      child: ListTile(
        contentPadding: EdgeInsets.all(16),
        title: Text(productModel.productName ?? " "),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: Image.network(
                productModel.thumbnailImageModel?.imageDownloadUrl ?? "",
                width: 100,
                height: 100,
                fit: BoxFit.cover,
              ),
            ),
            SizedBox(height: 8),
            Text('Price: \$${productModel.salePrice?.toString() ?? " "}'),
            SizedBox(height: 4),
            Text('Stock: ${productModel.stock?.toString() ?? " "}'),
            SizedBox(height: 8),
            Text('Long Description: ${productModel.longDescription ?? " "}'),
          ],
        ),
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => EditProduct(productModel: productModel),
            ),
          );
        },
      ),
    );
  }
}
