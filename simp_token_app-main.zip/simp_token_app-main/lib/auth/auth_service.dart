import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class AuthService {
  static final _auth = FirebaseAuth.instance;

  static User? get currentUser => _auth.currentUser;

  static Future<bool> login(String email, String password) async {
    final credential = await _auth.signInWithEmailAndPassword(
      email: email,
      password: password,
    );
    return credential.user != null;
  }

  static Future<bool> register(String email, String password) async {
    final credential = await _auth.createUserWithEmailAndPassword(
      email: email,
      password: password,
    );
    return credential.user != null;
  }

  static Future<UserCredential> signInAnonymously() =>
      _auth.signInAnonymously();

  static Future<void> logout() {
    return _auth.signOut();
  }

  static Future<bool> checkAdminCredentials(
      String email, String password) async {
    try {
      QuerySnapshot adminSnapshot = await FirebaseFirestore.instance
          .collection('admin')
          .where('email', isEqualTo: email)
          .where('password', isEqualTo: password)
          .limit(1)
          .get();

      return adminSnapshot.docs.isNotEmpty;
    } catch (e) {
      print('Error checking admin credentials: $e');
      return false;
    }
  }
}
