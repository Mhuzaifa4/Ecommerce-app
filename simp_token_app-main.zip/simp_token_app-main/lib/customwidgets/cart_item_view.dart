import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:simp_token_app/models/cart_model.dart';
import 'package:simp_token_app/providers/cart_provider.dart';
import 'package:simp_token_app/utils/constants.dart';
import 'package:simp_token_app/utils/sizedboxes.dart';
import 'package:simp_token_app/utils/theme.dart';

class CartItemView extends StatelessWidget {
  final CartModel cartModel;
  final CartProvider cartProvider;

  const CartItemView(
      {Key? key, required this.cartModel, required this.cartProvider})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          children: [
            ListTile(
              leading: CachedNetworkImage(
                width: 70,
                height: 70,
                imageUrl: cartModel.productImageUrl,
                placeholder: (context, url) => const Center(
                  child: CircularProgressIndicator(),
                ),
                errorWidget: (context, url, error) => const Icon(Icons.error),
              ),
              title: Text(
                cartModel.productName,
                style:
                    const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
              ),
              subtitle: Text('Unit Price: ${cartModel.salePrice}'),
              trailing: IconButton(
                onPressed: () {
                  cartProvider.removeFromCart(cartModel.productId);
                },
                icon: Icon(Icons.delete, color: SimpTokenColorTheme().red),
              ),
            ),
            Row(
              children: [
                IconButton(
                  onPressed: () {
                    cartProvider.decreaseQuantity(cartModel);
                  },
                  icon: Icon(
                    Icons.remove_circle,
                    size: 30,
                    color: SimpTokenColorTheme().primaryColor,
                  ),
                  color: SimpTokenColorTheme().logoColor,
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Text(
                    "${cartModel.quantity}",
                    style: Theme.of(context).textTheme.headline6,
                  ),
                ),
                IconButton(
                  onPressed: () {
                    cartProvider.increaseQuantity(cartModel);
                  },
                  icon: Icon(
                    Icons.add_circle,
                    size: 30,
                    color: SimpTokenColorTheme().primaryColor,
                  ),
                ),
                const Spacer(),
                Text(
                  '$currencySymbol${cartProvider.priceWithQuantity(cartModel)}',
                  style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                ),
                SizedBoxes.horizontalBig
              ],
            ),
          ],
        ),
      ),
    );
  }
}
