import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:simp_token_app/models/product_model.dart';
import 'package:simp_token_app/providers/product_provider.dart';

import '../models/category_model.dart';
import '../pages/product_details_page.dart';
import '../utils/helper_functions.dart';

class DiscountedItemsList extends StatelessWidget {
  List<ProductModel> discountedProducts;
  final String? selectedCategory;

  DiscountedItemsList({required this.discountedProducts,this.selectedCategory});

  @override
  Widget build(BuildContext context) {
    // List<ProductModel> pp = ProductProvider().productList;
    // print("ARRAY PLEASE ${pp.length}");
    discountedProducts = FilterDiscountedProduct(discountedProducts,selectedCategory);
    // print(discountedProducts);
    return
      AlertDialog(
                shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.all(Radius.circular(32.0))),
                contentPadding: EdgeInsets.only(top: 0.0),
                content: Stack(
                  children: <Widget>[
                    Container(
                      width: MediaQuery.of(context).size.width,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        mainAxisSize: MainAxisSize.min,
                        children: <Widget>[
                          SizedBox(
                            height: 20.0,
                          ),
                          Container(
                            height: MediaQuery.of(context).size.height / 2.0,
                            width: MediaQuery.of(context).size.width / 1,
                            child: ListView.builder(
                              scrollDirection: Axis.horizontal,
                              itemCount: discountedProducts.length,
                              itemBuilder: (context, index) {
                                final product = discountedProducts[index];
                                return Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Column(
                                    children: [
                                      Padding(
                                        padding: const EdgeInsets.only(top: 15.0,left: 15,right: 15),
                                        child: GestureDetector(
                                          onTap: () {
                                            Navigator.pushNamed(
                                              context,
                                              ProductDetailsPage.routeName,
                                              arguments: product,
                                            );
                                          },
                                          child: Image(
                                            image: NetworkImage(
                                              product.thumbnailImageModel.imageDownloadUrl,
                                            ),
                                            fit: BoxFit.cover,
                                            width: MediaQuery.of(context).size.width / 1.5,
                                            height: MediaQuery.of(context).size.width / 1.5,
                                          ),
                                        ),
                                      ),
                                      const SizedBox(height: 10.0),
                                      Text(
                                        "${product.productName}",
                                        style: const TextStyle(
                                          fontSize: 14.0,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                      const SizedBox(height: 10),
                                      Text("Original Price: ${product.salePrice}"),
                                      const SizedBox(height: 10),
                                      Text("Price after Discount: ${getPriceAfterDiscount(product.salePrice,product.productDiscount)}"),
                                    ],
                                  ),
                                );
                              },
                            ),
                          ),
                        ],
                      ),
                    ),
                    Positioned(
                      top: 0.0,
                      right: 0.0,
                      child: FloatingActionButton(
                        child: Icon(Icons.close),
                        onPressed: (){
                          Navigator.pop(context);
                        },
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(80)),
                        backgroundColor: Colors.white,
                        mini: true,
                        elevation: 5.0,
                      ),
                    ),
                  ],
                )
            );
          }

    //   AlertDialog(
    //   title: Text(
    //     "Discounted Items",
    //     textAlign: TextAlign.center,
    //   ),
    //   content: Container(
    //     height: MediaQuery.of(context).size.height / 2.0,
    //     width: MediaQuery.of(context).size.width / 1,
    //     child: ListView.builder(
    //       scrollDirection: Axis.horizontal,
    //       itemCount: discountedProducts.length,
    //       itemBuilder: (context, index) {
    //         final product = discountedProducts[index];
    //         return Padding(
    //           padding: const EdgeInsets.all(8.0),
    //           child: Column(
    //             children: [
    //               GestureDetector(
    //                 onTap: () {
    //                   Navigator.pushNamed(
    //                     context,
    //                     ProductDetailsPage.routeName,
    //                     arguments: product,
    //                   );
    //                 },
    //                 child: Image(
    //                   image: NetworkImage(
    //                     product.thumbnailImageModel.imageDownloadUrl,
    //                   ),
    //                   fit: BoxFit.cover,
    //                   width: MediaQuery.of(context).size.width / 1.5,
    //                   height: MediaQuery.of(context).size.width / 1.5,
    //                 ),
    //               ),
    //               const SizedBox(height: 10.0),
    //               Text(
    //                 "${product.productName}",
    //                 style: const TextStyle(
    //                   fontSize: 14.0,
    //                   fontWeight: FontWeight.bold,
    //                 ),
    //               ),
    //               const SizedBox(height: 10),
    //               Text("Original Price: ${product.salePrice}"),
    //               const SizedBox(height: 10),
    //               Text("Price after Discount: ${product.productDiscount}"),
    //             ],
    //           ),
    //         );
    //       },
    //     ),
    //   ),
    // );
  // }
}

// List<ProductModel> FilterDiscountedProduct(List<ProductModel> list,CategoryModel category){
//   List<ProductModel> discountedListFiltered = [];
//
//   for(int i =0;i< list.length;i++){
//     if(list[i]== category.categoryName){
//       print(category.categoryName);
//         discountedListFiltered.add(list[i]);
//     }
//     // if(list[i].productDiscount != 0 && list[i].category == category.categoryName){
//     //   discountedListFiltered.add(list[i]);
//     // }
//   }
//   return discountedListFiltered;
// }

List<ProductModel> FilterDiscountedProduct(List<ProductModel> list, String? categoryName) {
  List<ProductModel> discountedListFiltered = [];
  // print("CATEGORY NAME : ${categoryName} length ${list.length}");

  for (int i = 0; i < list.length; i++) {

    // print("${list[i].category} can you see $i");

    if (list[i].category.categoryName == categoryName) {
      // if (list[i].productDiscount != 0 && list[i].category.categoryName == categoryName) {
      discountedListFiltered.add(list[i]);
    }
  }
  if(discountedListFiltered.isEmpty){
    discountedListFiltered = list;
  }
  return discountedListFiltered;
}