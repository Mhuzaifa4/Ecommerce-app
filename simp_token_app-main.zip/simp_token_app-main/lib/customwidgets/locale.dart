import 'package:flutter/material.dart';

class MyLocalization extends ChangeNotifier {
  String _languageCode = 'en'; // Default language is English

  String get languageCode => _languageCode;

  // Map to store translations for each language
  final Map<String, Map<String, String>> _translations = {
    'en': {
      'login': 'Login',
      'login_as_guest': 'Login as Guest',
      'create_your_account': 'Create your Account',
      'username': 'Username',
      'email': 'Email',
      'password': 'Password',
      'sign_up': 'Sign Up',
      'dont_have_an_account': "Don't have an account?",
      'sign_in': 'Sign In',
      'login_into_your_account': 'Login into Your Account',
      'phone_number': 'Phone Number',
      'mobile_number': 'Mobile Number',
      'address_line_1': 'Address Line 1',
      'address_line_2': 'Address Line 2',
      'city': 'City',
      'zip_code': 'Zip Code',
      'set_zip_code': 'Set Zip Code',
      'shop': 'Shop',
      'search_product': 'Search products...',
      'otp_verification': 'OTP Verification',
      'verify_phone_number': 'Verify Phone Number',
      'otp_sent':
          'An OTP code is sent to your mobile number. Enter the OTP code below',
      'verify': 'Verify',
      'order_has_been_placed': 'Your order has been placed',
      'quantity': 'Quantity',
      'order_placed_at': 'Order Placed at',
      'no_favorite_products_yet': 'No favorite products yet!',
      'cart_Items': 'Cart Items',
      'error_loading_cart_data': 'Error loading cart data',
      'checkout': 'CHECKOUT',
      'chat_support': 'Chat Support',
      'send_message': 'Send a message...',
      'product_info': 'Product Info',
      'order_summary': 'Order Summary',
      'delivery_address': 'Delivery Address',
      'payment_method': 'Payment Method',
      'sub_total': 'Sub - total',
      'discount': 'Discount %)',
      'vat': 'VAT (0%)',
      'delivery_charge': 'Delivery Charge',
      'grand_total': 'Grand Total',
      'select_your_city': 'Select your city',
      'place_order': 'PLACE ORDER',
      'about_us': 'About Us',
      'faqs': "FAQ's",
      'terms_conditions': 'Terms & Conditions',
      'return_and_exchange': 'Return & Exchange Policy',
      'logout': 'Logout',
      'subtotal': 'SUBTOTAL',
      'already_have_account':'Already have an account?'
    },
    'de': {
      'login': 'Anmelden',
      'login_as_guest': 'Als Gast anmelden',
      'create_your_account': 'Erstelle dein Konto',
      'username': 'Benutzername',
      'email': 'E-Mail',
      'password': 'Passwort',
      'sign_up': 'Registrieren',
      'dont_have_an_account': 'Du hast noch kein Konto?',
      'sign_in': 'Anmelden',
      'login_into_your_account': 'In dein Konto einloggen',
      'phone_number': 'Telefonnummer',
      'mobile_number': 'Handynummer',
      'address_line_1': 'Adresszeile 1',
      'address_line_2': 'Adresszeile 2',
      'city': 'Stadt',
      'zip_code': 'Postleitzahl',
      'set_zip_code': 'Postleitzahl festlegen',
      'shop': 'Einkaufen',
      'search_product': 'Produkte suchen...',
      'otp_verification': 'OTP-Verifizierung',
      'verify_phone_number': 'Telefonnummer verifizieren',
      'otp_sent':
          'Ein OTP-Code wurde an deine Handynummer gesendet. Gib den OTP-Code unten ein.',
      'verify': 'Verifizieren',
      'order_has_been_placed': 'Deine Bestellung wurde aufgegeben',
      'quantity': 'Menge',
      'order_placed_at': 'Bestellung aufgegeben am',
      'no_favorite_products_yet': 'Noch keine Lieblingsprodukte!',
      'cart_Items': 'Warenkorbartikel',
      'error_loading_cart_data': 'Fehler beim Laden der Warenkorbdaten',
      'checkout': 'KAUFEN',
      'chat_support': 'Chat-Support',
      'send_message': 'Nachricht senden...',
      'product_info': 'Produktinformation',
      'order_summary': 'Bestellzusammenfassung',
      'delivery_address': 'Lieferadresse',
      'payment_method': 'Zahlungsmethode',
      'sub_total': 'Zwischensumme',
      'discount': 'Rabatt %)',
      'vat': 'MwSt (0%)',
      'delivery_charge': 'Liefergebühr',
      'grand_total': 'Gesamtsumme',
      'select_your_city': 'Wähle deine Stadt',
      'place_order': 'BESTELLUNG AUFGEBEN',
      'about_us': 'Über uns',
      'faqs': "FAQ's",
      'terms_conditions': 'Geschäftsbedingungen',
      'return_and_exchange': 'Rückgabe- und Umtauschrichtlinie',
      'logout': 'Abmelden',
      'subtotal': 'Zwischensumme',
            'already_have_account':'Sie haben bereits ein Konto?'

    }

    // Add more languages and translations as needed
  };

  void setLocale(String languageCode) {
    _languageCode = languageCode;
    notifyListeners();
  }

  String translate(String key) {
    // Check if the key exists in the translations map
    if (_translations.containsKey(_languageCode) &&
        _translations[_languageCode]!.containsKey(key)) {
      return _translations[_languageCode]![key]!;
    } else {
      // Return an empty string for unknown keys or languages
      return '';
    }
  }
}
