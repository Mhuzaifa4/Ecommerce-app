// ignore_for_file: must_be_immutable

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:simp_token_app/auth/auth_service.dart';
import 'package:simp_token_app/customwidgets/locale.dart';
import 'package:simp_token_app/customwidgets/reusable_btn.dart';
import 'package:simp_token_app/pages/launcher_page.dart';
import 'package:simp_token_app/utils/image_constants.dart';
import 'package:simp_token_app/utils/sizedboxes.dart';
import 'package:simp_token_app/utils/theme.dart';
import 'package:url_launcher/url_launcher.dart';

class MainDrawer extends StatelessWidget {
  const MainDrawer({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final localization = Provider.of<MyLocalization>(context);

    return Drawer(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBoxes.verticalExtraGargangua,
            Container(
              child: Image.asset(
                AppConstants.appLogo1,
                fit: BoxFit.fitHeight,
                width: 200,
              ),
            ),

            SizedBoxes.verticalExtraGargangua,
            SizedBox(
              height: 35,
              child: TextButton(
                  onPressed: () {
                    Navigator.pushNamed(context, "/aboutus");
                  },
                  child: Text(
                    localization.translate("about_us"),
                    style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                        color: SimpTokenColorTheme().primaryColor),
                  )),
            ),

            SizedBox(
              height: 35,
              child: TextButton(
                  onPressed: () {
                    Navigator.pushNamed(context, "/faqs");
                  },
                  child: Text(
                    localization.translate("faqs"),
                    style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                        color: SimpTokenColorTheme().primaryColor),
                  )),
            ),
            // SizedBoxes.verticalTiny,
            SizedBox(
              height: 35,
              child: TextButton(
                  onPressed: () {
                    Navigator.pushNamed(context, "/terms&conditions");
                  },
                  child: Text(
                    localization.translate("terms_conditions"),
                    style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                        color: SimpTokenColorTheme().primaryColor),
                  )),
            ),
            // SizedBoxes.verticalTiny,
            SizedBox(
              height: 35,
              child: TextButton(
                  onPressed: () {
                    Navigator.pushNamed(context, '/return&exhangepolicy');
                  },
                  child: Text(
                    localization.translate("return_and_exchange"),
                    style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                        color: SimpTokenColorTheme().primaryColor),
                  )),
            ),
            const Spacer(),
            ReUsableButton(
              title: localization.translate("logout"),
              onTap: () {
                AuthService.logout().then(
                  (value) => Navigator.pushReplacementNamed(
                      context, LauncherPage.routeName),
                );
              },
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                IconButton(
                  onPressed: () => _launchURL(
                      'https://twitter.com/i/flow/login?redirect_after_login=%2Fpepeandlino'),
                  icon: Icon(Icons.facebook), // Use the Facebook icon
                ),
                SizedBoxes.horizontalMicro,
                IconButton(
                  onPressed: () => _launchURL(
                      'https://www.instagram.com/pepeandlino/?igsh=MzdodzloMDVvOXF4&utm_source=qr'),
                  icon: Icon(Icons.facebook_outlined), // Use the Instagram icon
                ),
                SizedBoxes.horizontalMicro,
                IconButton(
                  onPressed: () => _launchURL(
                      'https://www.tiktok.com/@pepeandlino?_t=8iVghQHDZ5s'),
                  icon: Icon(Icons
                      .ondemand_video), // Use the TikTok icon (You can explore other icons in the Icons class)
                ),
              ],
            ),

            SizedBoxes.verticalLarge,
            Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  CupertinoIcons.location_fill,
                  color: Colors.grey.shade600,
                  size: 15,
                ),
                SizedBoxes.horizontalMicro,
                const Text(
                  "451 Wall Street, UK, London",
                  style: TextStyle(fontWeight: FontWeight.w500, fontSize: 12),
                ),
              ],
            ),
            SizedBoxes.verticalMicro,
            Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  CupertinoIcons.phone_fill,
                  color: Colors.grey.shade600,
                  size: 15,
                ),
                SizedBoxes.horizontalMicro,
                const Text(
                  "Phone: (064) 332-1233",
                  style: TextStyle(fontWeight: FontWeight.w500, fontSize: 12),
                ),
              ],
            ),
            SizedBoxes.verticalMicro,
            Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  CupertinoIcons.mail,
                  color: Colors.grey.shade600,
                  size: 15,
                ),
                SizedBoxes.horizontalMicro,
                const Text(
                  "Fax: (099) 453-1357",
                  style: TextStyle(fontWeight: FontWeight.w500, fontSize: 12),
                ),
              ],
            ),
            SizedBoxes.verticalExtraGargangua,
          ],
        ),
      ),
    );
  }
}

_launchURL(String url) async {
  if (await canLaunch(url)) {
    await launch(url);
  } else {
    throw 'Could not launch $url';
  }
}
