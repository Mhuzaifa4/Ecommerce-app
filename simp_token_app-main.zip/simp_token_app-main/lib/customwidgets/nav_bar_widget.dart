import 'package:flutter/material.dart';
import 'package:google_nav_bar/google_nav_bar.dart';
import 'package:simp_token_app/customwidgets/main_drawer.dart';
import 'package:simp_token_app/customwidgets/reusbale_appbar.dart';
import 'package:simp_token_app/providers/nav_bar_controller.dart';
import 'package:simp_token_app/utils/theme.dart';
import 'package:provider/provider.dart';

class MyBottomNavbar extends StatelessWidget {
  static const String routeName = '/MyBottomNavBar';

  @override
  Widget build(BuildContext context) {
    return Consumer<BottomNavBarController>(
      builder: (context, bottomNavBarController, _) {
        final GlobalKey<ScaffoldState> _scaffoldKey =
            GlobalKey<ScaffoldState>();

        return WillPopScope(
            onWillPop: () async {
              // If on the first screen, show confirmation dialog
              if (bottomNavBarController.currentIndex == 0 ||
                  bottomNavBarController.currentIndex == 1 ||
                  bottomNavBarController.currentIndex == 2 ||
                  bottomNavBarController.currentIndex == 3 ||
                  bottomNavBarController.currentIndex == 4) {
                return await showExitConfirmationDialog(context);
              } else {
                // Navigate to the previous screen if not on the first screen
                bottomNavBarController.changeScreen(0);
                return false;
              }
            },
            child: Scaffold(
              key: _scaffoldKey,
              endDrawer: MainDrawer(),
              appBar: CustomAppBar(
                scaffoldKey: _scaffoldKey,
                currentIndex: bottomNavBarController.currentIndex,
                onSearch: (searchTerm) {
                  print("Search term: $searchTerm");
                },
              ),
              body: PageStorage(
                bucket: PageStorageBucket(),
                child: bottomNavBarController.currentScreen,
              ),
              bottomNavigationBar: Container(
                decoration: const BoxDecoration(
                  color: Colors.red,
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(10),
                    topRight: Radius.circular(10),
                  ),
                ),
                child: GNav(
                  backgroundColor: Colors.white,
                  selectedIndex: bottomNavBarController.currentIndex,
                  onTabChange: (index) {
                    print(index);
                    bottomNavBarController.changeScreen(index);
                  },
                  padding:
                      const EdgeInsets.symmetric(vertical: 6, horizontal: 5),
                  tabBorderRadius: 10,
                  color: SimpTokenColorTheme().primaryColor,
                  activeColor: SimpTokenColorTheme().white,
                  tabBackgroundColor: SimpTokenColorTheme().primaryColor,
                  gap: 8,
                  tabMargin:
                      const EdgeInsets.symmetric(vertical: 8, horizontal: 5),
                  tabs: [
                    GButton(
                      onPressed: () {},
                      icon: Icons.home,
                      text: 'Home',
                    ),
                    GButton(
                      onPressed: () {
                        // Navigate to the Social screen.
                      },
                      icon: Icons.shop,
                      text: 'Shop',
                    ),
                    GButton(
                      onPressed: () {
                        // Navigate to the Marketplace screen.
                      },
                      icon: Icons.favorite,
                      text: 'Favourites',
                    ),
                    GButton(
                      onPressed: () {
                        // Navigate to the Adoption screen.
                      },
                      icon: Icons.calendar_month,
                      text: 'Orders',
                    ),
                    GButton(
                      onPressed: () {},
                      icon: Icons.person_2,
                      text: 'Profile',
                    ),
                  ],
                ),
              ),
            ));
      },
    );
  }
}

showExitConfirmationDialog(BuildContext context) async {
  return showDialog(
    context: context,
    builder: (context) => AlertDialog(
      title: Text('Confirm Exit'),
      content: Text('Are you sure you want to exit the app?'),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(false),
          child: Text('No'),
        ),
        TextButton(
          onPressed: () => Navigator.of(context).pop(true),
          child: Text('Yes'),
        ),
      ],
    ),
  );
}
