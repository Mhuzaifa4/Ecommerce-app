import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:simp_token_app/models/product_model.dart';
import 'package:simp_token_app/pages/product_details_page.dart';

class ProductGridItemView extends StatelessWidget {
  final ProductModel productModel;

  const ProductGridItemView({Key? key, required this.productModel})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {
        Navigator.pushNamed(context, ProductDetailsPage.routeName,
            arguments: productModel);
      },
      child: Card(
        child: Column(
          children: [
            ClipRRect(
                borderRadius: const BorderRadius.only(
                    topLeft: Radius.circular(20),
                    topRight: Radius.circular(20)),
                child: Image.network(
                  productModel.thumbnailImageModel.imageDownloadUrl,
                  height: MediaQuery.of(context).size.height * 0.2,
                  width: double.maxFinite,
                  fit: BoxFit.fill,
                )),
            Padding(
              padding: const EdgeInsets.only(left: 10, right: 10, top: 10),
              child: Row(
                children: [
                  Flexible(
                    child: Text(
                      maxLines: 1,
                      productModel.productName,
                      style: const TextStyle(fontSize: 20, color: Colors.grey),
                    ),
                  ),
                  Spacer(),
                  RatingBar.builder(
                    initialRating: productModel.avgRating.toDouble(),
                    minRating: 0.0,
                    direction: Axis.horizontal,
                    allowHalfRating: true,
                    itemCount: 1,
                    ignoreGestures: true,
                    itemSize: 20,
                    itemPadding: const EdgeInsets.symmetric(horizontal: 0.0),
                    itemBuilder: (context, _) => const Icon(
                      Icons.star,
                      color: Colors.amber,
                    ),
                    onRatingUpdate: (rating) {
                      print(rating);
                    },
                  ),
                  Text(" ${productModel.avgRating.toStringAsFixed(1)}"),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
