import 'package:flutter/material.dart';
import 'package:simp_token_app/utils/theme.dart';

class ReUsableButton extends StatelessWidget {
  final String title;
  final VoidCallback onTap;
  final bool loading;
  const ReUsableButton({
    super.key,
    required this.title,
    required this.onTap,
    this.loading = false,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Center(
        child: Container(
          height: 50,
          width: 360,
          decoration: BoxDecoration(
              color: SimpTokenColorTheme().primaryButtonColor,
              borderRadius: BorderRadius.circular(15)),
          child: Center(
              child: loading
                  ? const CircularProgressIndicator(
                      color: Colors.white,
                    )
                  : Text(
                      title,
                      style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 16),
                    )),
        ),
      ),
    );
  }
}
