import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:simp_token_app/customwidgets/cart_bubble_view.dart';
import 'package:simp_token_app/pages/cart_page.dart';
import 'package:simp_token_app/providers/nav_bar_controller.dart';
import 'package:simp_token_app/utils/image_constants.dart';
import 'package:simp_token_app/utils/theme.dart';

class CustomAppBar extends StatelessWidget implements PreferredSizeWidget {
  const CustomAppBar({
    Key? key,
    required this.scaffoldKey,
    required this.currentIndex,
    required this.onSearch,
  }) : super(key: key);

  final GlobalKey<ScaffoldState> scaffoldKey;
  final int currentIndex;
  final void Function(String) onSearch;

  @override
  Widget build(BuildContext context) {
    final bool showSearchIcon = currentIndex == 1;
    final bottomNavBarController = Provider.of<BottomNavBarController>(context);

    return AppBar(
      backgroundColor: SimpTokenColorTheme().white,
      automaticallyImplyLeading: false,
      title: Container(
        child: InkWell(
          onTap: () {
            bottomNavBarController.changeScreen(0);
          },
          child: Image.asset(
            AppConstants.appLogo1,
            fit: BoxFit.fitHeight,
            width: 200,
          ),
        ),
      ),
      actions: [
        if (showSearchIcon)
          IconButton(
            icon: const Icon(Icons.search, color: Colors.black, size: 33.0),
            onPressed: () {
              _showSearchBottomSheet(context);
            },
          ),
        CartBubbleView(),
        IconButton(
          icon: const Icon(Icons.menu, color: Colors.black, size: 33.0),
          onPressed: () {
            final scaffoldState = scaffoldKey.currentState;
            if (scaffoldState != null) {
              scaffoldState.openEndDrawer();
            }
          },
        ),
      ],
    );
  }

  void _showSearchBottomSheet(BuildContext context) {
    showModalBottomSheet(
      context: context,
      builder: (BuildContext context) {
        TextEditingController searchController = TextEditingController();

        return Padding(
          padding: EdgeInsets.all(16.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: searchController,
                decoration: InputDecoration(
                  hintText: "Enter product name...",
                ),
              ),
              SizedBox(height: 16.0),
              ElevatedButton(
                onPressed: () {
                  String searchTerm = searchController.text;
                  onSearch(searchTerm);
                  Navigator.pop(context);
                },
                child: Text("Search"),
              ),
            ],
          ),
        );
      },
    );
  }

  @override
  Size get preferredSize => const Size.fromHeight(kToolbarHeight);
}
