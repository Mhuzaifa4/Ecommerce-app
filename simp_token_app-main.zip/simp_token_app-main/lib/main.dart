import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:provider/provider.dart';
import 'package:simp_token_app/customwidgets/locale.dart';
import 'package:simp_token_app/customwidgets/nav_bar_widget.dart';
import 'package:simp_token_app/pages/about_us_view.dart';
import 'package:simp_token_app/pages/cart_page.dart';
import 'package:simp_token_app/pages/chat_page.dart';
import 'package:simp_token_app/pages/checkout_page.dart';
import 'package:simp_token_app/pages/contact_us_view.dart';
import 'package:simp_token_app/pages/faqs_page.dart';
import 'package:simp_token_app/pages/launcher_page.dart';
import 'package:simp_token_app/pages/login_page.dart';
import 'package:simp_token_app/pages/order_page.dart';
import 'package:simp_token_app/pages/order_successful_page.dart';
import 'package:simp_token_app/pages/product_details_page.dart';
import 'package:simp_token_app/pages/return_and_exchange_policy_view.dart';
import 'package:simp_token_app/pages/shop_page.dart';
import 'package:simp_token_app/pages/signup_page.dart';
import 'package:simp_token_app/pages/terms_and_conditions_page.dart';
import 'package:simp_token_app/pages/user_profile_page.dart';
import 'package:simp_token_app/pages/view_product_page.dart';
import 'package:simp_token_app/pages/welcome_page.dart';
import 'package:simp_token_app/providers/cart_provider.dart';
import 'package:simp_token_app/providers/chat_provider.dart';
import 'package:simp_token_app/providers/favourite_provider.dart';
import 'package:simp_token_app/providers/nav_bar_controller.dart';
import 'package:simp_token_app/providers/order_provider.dart';
import 'package:simp_token_app/providers/product_provider.dart';
import 'package:simp_token_app/providers/signup_provider.dart';
import 'package:simp_token_app/providers/user_provider.dart';
import 'firebase_options.dart';

@pragma('vm:entry-point')
Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  // If you're going to use other Firebase services in the background, such as Firestore,
  // make sure you call `initializeApp` before using other Firebase services.

  print("Handling a background message: ${message.toMap()}");
}

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  final fcmToken = await FirebaseMessaging.instance.getToken();
  print('FCM TOKEN: $fcmToken');
  FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);
  await FirebaseMessaging.instance.subscribeToTopic("promo");
  await FirebaseMessaging.instance.subscribeToTopic("user");
  runApp(MultiProvider(providers: [
    ChangeNotifierProvider(
      create: (_) => ProductProvider(),
      child: UserProfilePage(),
    ),
    ChangeNotifierProvider(
      create: (_) => MyLocalization(),
    ),
    ChangeNotifierProvider(
      create: (context) => OrderProvider(),
      child: OrderPage(),
    ),
    ChangeNotifierProvider(create: (_) => UserProvider()),
    ChangeNotifierProvider(create: (_) => SignUpController()),
    ChangeNotifierProvider(create: (_) => CartProvider()),
    ChangeNotifierProvider(create: (_) => FavouriteProvider()),
    ChangeNotifierProvider(create: (_) => ChatProvider()),
    ChangeNotifierProvider(
      create: (_) => BottomNavBarController(),
    ), // Add this line
  ], child: const MyApp()));
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.

  @override
  Widget build(BuildContext context) {
    Provider.of<CartProvider>(context, listen: false).getAllCartItemsByUser();

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      builder: EasyLoading.init(),
      localizationsDelegates: [],
      supportedLocales: const [
        Locale('en', 'US'),
        Locale('de', 'DE'),
      ],
      initialRoute: LauncherPage.routeName,
      routes: {
        LauncherPage.routeName: (_) => const LauncherPage(),
        WelcomePage.routeName: (_) => const WelcomePage(),
        LoginPage.routeName: (_) => const LoginPage(),
        SignUpPage.routeName: (_) => const SignUpPage(),
        MyBottomNavbar.routeName: (_) => MyBottomNavbar(),
        ViewProductPage.routeName: (_) => const ViewProductPage(),
        ShopPage.routeName: (_) => const ShopPage(),
        ProductDetailsPage.routeName: (_) => ProductDetailsPage(),
        OrderPage.routeName: (_) => const OrderPage(),
        UserProfilePage.routeName: (_) => const UserProfilePage(),
        CartPage.routeName: (_) => CartPage(),
        CheckoutPage.routeName: (_) => CheckoutPage(),
        OrderSuccessfulPage.routeName: (_) => OrderSuccessfulPage(),
        ChatPage.routeName: (_) => ChatPage(),
        AboutUs.routeName: (_) => AboutUs(),
        ContactUs.routeName: (_) => ContactUs(),
        ReturnAndExchangePolicyView.routeName: (_) =>
            ReturnAndExchangePolicyView(),
        TermsAndConditionsPage.routeName: (_) => TermsAndConditionsPage(),
        FAQsPage.routeName: (_) => FAQsPage(),
      },
    );
  }
}
