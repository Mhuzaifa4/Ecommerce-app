import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:simp_token_app/models/address_model.dart';
import 'package:simp_token_app/models/cart_model.dart';
import 'package:simp_token_app/models/date_model.dart';

const String collectionOrder = 'Order';

const String orderFieldOrderId = 'orderId';
const String orderFieldUserId = 'userId';
const String orderFieldGrandTotal = 'grandTotal';
const String orderFieldOrderStatus = 'orderStatus';
const String orderFieldPaymentMethod = 'paymentMethod';
const String orderFieldOrderDate = 'orderDate';
const String orderFieldDeliveryAddress = 'deliveryAddress';
const String orderFieldProductDetails = 'productDetails';

class OrderModel {
  String orderId;
  String userId;
  String orderStatus;
  String paymentMethod;
  num grandTotal;
  DateModel orderDate;
  AddressModel deliveryAddress;
  List<CartModel> productDetails;

  OrderModel(
      {required this.orderId,
      required this.userId,
      required this.orderStatus,
      required this.paymentMethod,
      required this.grandTotal,
      required this.orderDate,
      required this.deliveryAddress,
      required this.productDetails});

       Future<void> updateOrderStatus(String newStatus) async {
    try {
      await FirebaseFirestore.instance
          .collection(collectionOrder)
          .doc(orderId)
          .update({
        orderFieldOrderStatus: newStatus,
      });
    } catch (error) {
      print('Error updating order status: $error');
    }
  }

  Map<String, dynamic> toMap() {
    return <String, dynamic>{
      orderFieldOrderId: orderId,
      orderFieldUserId: userId,
      orderFieldOrderStatus: orderStatus,
      orderFieldPaymentMethod: paymentMethod,
      orderFieldGrandTotal: grandTotal,
      orderFieldOrderDate: orderDate.toMap(),
      orderFieldDeliveryAddress: deliveryAddress.toMap(),
      orderFieldProductDetails: List.generate(
          productDetails.length, (index) => productDetails[index].toMap()),
    };
  }

  factory OrderModel.fromMap(Map<String, dynamic> map) {
    return OrderModel(
      orderId: map[orderFieldOrderId],
      userId: map[orderFieldUserId],
      orderStatus: map[orderFieldOrderStatus],
      paymentMethod: map[orderFieldPaymentMethod],
      grandTotal: map[orderFieldGrandTotal],
      orderDate: DateModel.fromMap(map[orderFieldOrderDate]),
      deliveryAddress: AddressModel.fromMap(map[orderFieldDeliveryAddress]),
      productDetails: parseProductDetails(map[orderFieldProductDetails]),
    );
  }
}

List<CartModel> parseProductDetails(dynamic productDetails) {
  if (productDetails is List) {
    return productDetails.map((e) => CartModel.fromMap(e)).toList();
  } else if (productDetails is Map) {
    return productDetails.values.map((e) => CartModel.fromMap(e)).toList();
  } else {
    return [];
  }
}
