import 'package:flutter/material.dart';
import 'package:simp_token_app/utils/image_constants.dart';
import 'package:simp_token_app/utils/sizedboxes.dart';
import 'package:simp_token_app/utils/theme.dart';

class AboutUs extends StatelessWidget {
  static const String routeName = '/aboutus';

  const AboutUs({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        toolbarHeight: 100,
        backgroundColor: SimpTokenColorTheme().white,
        automaticallyImplyLeading: true,
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              child: Image.asset(
                AppConstants.appLogo1,
                fit: BoxFit.fitHeight,
                width: 200,
              ),
            ),
            const Text(
              "About Us",
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
            )
          ],
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "About Pepe & Lino",
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
              ),
              Text(
                "Welcome to Pepe & Lino",
                style: TextStyle(
                    fontWeight: FontWeight.w500,
                    fontSize: 14,
                    color: Colors.grey.shade400),
              ),
              SizedBoxes.verticalLarge,
              const Text(
                "About",
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
              ),
              SizedBoxes.vertical2Px,
              Text(
                """where we celebrate the individuality of every child and are aware of our responsibility towards the environment and society. We are proud to be a passionate brand for sustainable and high-quality baby and children's clothing, committed to a better world.
          """,
                style: TextStyle(
                    fontWeight: FontWeight.w400,
                    fontSize: 12,
                    color: Colors.grey.shade500),
              ),
              // SizedBoxes.verticalTiny,
              const Text(
                "Our history",
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
              ),
              SizedBoxes.vertical2Px,
              Text(
                """The Pepe & Lino story began with a desire to create clothing for our own children that showcases their unique style and personality. As parents, we wanted to ensure that our little ones could wear comfortable, high-quality clothing that not only serves their comfort, but also aligns with our values ​​of sustainability and social responsibility.
                """,
                style: TextStyle(
                    fontWeight: FontWeight.w400,
                    fontSize: 12,
                    color: Colors.grey.shade500),
              ),
              Image.asset(
                AppConstants.appLogo1,
                fit: BoxFit.fitHeight,
                width: 200,
              ),
              SizedBoxes.verticalLarge,

              const Text(
                "Sustainability and responsibility",
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
              ),
              SizedBoxes.vertical2Px,
              Text(
                """At Pepe & Lino, sustainability and social responsibility are at the core of our identity. Our entire collection is GOTS certified, meaning our clothing meets strict environmental and social standards. We only use organic materials that are good for your child and our environment. As part of our commitment to sustainability, we are proud to monitor and offset our carbon emissions.
                """,
                style: TextStyle(
                    fontWeight: FontWeight.w400,
                    fontSize: 12,
                    color: Colors.grey.shade500),
              ),
              SizedBoxes.verticalMicro,

              const Text(
                "Our community",
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
              ),
              SizedBoxes.vertical2Px,
              Text(
                """We are a family-run company with a dedicated team who share our values. Pepe & Lino was founded to create a community of parents and children who share the joy of sustainable and high-quality clothing.

Would you like to join us or do you have any questions? Do not hesitate  to reach us at help@pepe-lino.de .

Thank you for making Pepe & Lino part of your journey through the world of sustainable and responsible children's clothing. 09:55 PM

""",
                style: TextStyle(
                    fontWeight: FontWeight.w400,
                    fontSize: 12,
                    color: Colors.grey.shade500),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
