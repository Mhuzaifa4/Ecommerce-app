import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:simp_token_app/customwidgets/cart_item_view.dart';
import 'package:simp_token_app/customwidgets/locale.dart';
import 'package:simp_token_app/pages/checkout_page.dart';
import 'package:simp_token_app/providers/cart_provider.dart';
import 'package:simp_token_app/utils/constants.dart';
import 'package:simp_token_app/utils/image_constants.dart';
import 'package:simp_token_app/utils/theme.dart';

class CartPage extends StatelessWidget {
  static const String routeName = '/cart';

  CartPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final localization = Provider.of<MyLocalization>(context);

    return Scaffold(
      appBar: AppBar(
        toolbarHeight: 100,
        backgroundColor: SimpTokenColorTheme().white,
        automaticallyImplyLeading: true,
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              child: Image.asset(
                AppConstants.appLogo1,
                fit: BoxFit.fitHeight,
                width: 200,
              ),
            ),
            Text(
              localization.translate("cart_Items"),
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
            ),
          ],
        ),
      ),
      body: FutureBuilder(
        future: Provider.of<CartProvider>(context, listen: false)
            .getAllCartItemsByUser(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Scaffold(
              body: Center(
                child: CircularProgressIndicator(),
              ),
            );
          } else if (snapshot.hasError) {
            return Scaffold(
              body: Center(
                child: Text(
                  localization.translate("error_loading_cart_data"),
                ),
              ),
            );
          } else {
            return Scaffold(
              body: Consumer<CartProvider>(
                builder: (context, provider, child) => Column(
                  children: [
                    Expanded(
                      child: ListView.builder(
                        padding: EdgeInsets.zero,
                        itemCount: provider.cartList.length,
                        itemBuilder: (context, index) {
                          final cartModel = provider.cartList[index];
                          var productStock = cartModel
                              .stock; // Get the product stock from cartModel

                          return CartItemView(
                            cartModel: cartModel,
                            cartProvider: provider,
                          );
                        },
                      ),
                    ),
                    Card(
                      margin: EdgeInsets.zero,
                      color: SimpTokenColorTheme().primaryButtonColor,
                      elevation: 12.0,
                      shape: const RoundedRectangleBorder(
                        borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(20),
                          topRight: Radius.circular(20),
                        ),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(12),
                        child: Row(
                          children: [
                            Expanded(
                              child: Text(
                                '${localization.translate("subtotal")}: $currencySymbol${provider.getCartSubTotal()}',
                                style: TextStyle(
                                  fontSize: 22,
                                  fontWeight: FontWeight.bold,
                                  color: SimpTokenColorTheme().white,
                                ),
                              ),
                            ),
                            OutlinedButton(
                              onPressed: () {
                                if (provider.cartList.isNotEmpty) {
                                  final num productStock =
                                      provider.cartList[0].stock;
                                  final num quantity =
                                      provider.cartList[0].quantity;

                                  if (quantity > productStock) {
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      SnackBar(
                                        content: Text(
                                          "Sorry, we only have $productStock items available. Please reduce the quantity in your cart.",
                                        ),
                                      ),
                                    );
                                  } else {
                                    List<String> productIds = provider.cartList
                                        .map((cartModel) => cartModel.productId)
                                        .toList();

                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                        builder: (context) => CheckoutPage(
                                          pID: productIds.first,
                                        ),
                                      ),
                                    );
                                  }
                                }
                              },
                              child: Text(
                                localization.translate("checkout"),
                                style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                  color: SimpTokenColorTheme().white,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            );
          }
        },
      ),
    );
  }
}
