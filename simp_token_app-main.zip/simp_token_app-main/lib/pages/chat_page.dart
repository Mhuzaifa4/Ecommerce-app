import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:simp_token_app/customwidgets/locale.dart';
import 'package:simp_token_app/providers/chat_provider.dart';
import 'package:simp_token_app/utils/image_constants.dart';
import 'package:simp_token_app/utils/sizedboxes.dart';
import 'package:simp_token_app/utils/theme.dart';
import 'package:flutter_hooks/flutter_hooks.dart';

class ChatPage extends HookWidget {
  static const String routeName = '/chatpage';

  final TextEditingController _textController = TextEditingController();

  @override
  Widget build(BuildContext context) {
        final localization = Provider.of<MyLocalization>(context);

    var chatProvider = Provider.of<ChatProvider>(context);

    // useEffect(() {
    //   chatProvider.initialize();
    //   return null; 
    // }, []);

    return Scaffold(
      appBar: AppBar(
        toolbarHeight: 100,
        backgroundColor: SimpTokenColorTheme().white,
        automaticallyImplyLeading: false,
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              child: Image.asset(
                AppConstants.appLogo1,
                fit: BoxFit.fitHeight,
                width: 200,
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                 Text(
                  localization.translate("chat_support"),
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
                ),
                SizedBoxes.horizontalMicro,
                const CircleAvatar(
                    backgroundColor: Color.fromARGB(255, 55, 225, 61),
                    radius: 7)
              ],
            )
          ],
        ),
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              reverse: true,
              itemCount: chatProvider.messages.length,
              itemBuilder: (context, index) {
                final message = chatProvider.messages[index];
                return _buildMessage(message);
              },
            ),
          ),
          _buildComposer(context),
        ],
      ),
    );
  }

  Widget _buildMessage(Message message) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Row(
        mainAxisAlignment:
            message.isMe ? MainAxisAlignment.end : MainAxisAlignment.start,
        children: [
          Container(
            decoration: BoxDecoration(
              color: message.isMe
                  ? SimpTokenColorTheme().primaryColor
                  : Colors.grey.shade300,
              borderRadius: BorderRadius.circular(8.0),
            ),
            padding: const EdgeInsets.all(10.0),
            child: Text(
              message.text,
              style: TextStyle(
                  color: message.isMe
                      ? SimpTokenColorTheme().white
                      : SimpTokenColorTheme().black),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildComposer(BuildContext context) {
    var chatProvider = Provider.of<ChatProvider>(context);
        final localization = Provider.of<MyLocalization>(context);


    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8.0),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
      ),
      child: Row(
        children: [
          Expanded(
            child: TextField(
              controller: _textController,
              onSubmitted: (text) {
                chatProvider.sendMessage(text);
                _textController.clear();
              },
              decoration:  InputDecoration.collapsed(
                hintText: localization.translate("send_message"),
              ),
            ),
          ),
          IconButton(
            icon: const Icon(Icons.send),
            onPressed: () {
              chatProvider.sendMessage(_textController.text);
              _textController.clear();
            },
          ),
        ],
      ),
    );
  }
}
