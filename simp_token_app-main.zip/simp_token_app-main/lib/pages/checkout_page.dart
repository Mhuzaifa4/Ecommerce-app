import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:provider/provider.dart';
import 'package:simp_token_app/auth/auth_service.dart';
import 'package:simp_token_app/customwidgets/locale.dart';
import 'package:simp_token_app/customwidgets/reusable_btn.dart';
import 'package:simp_token_app/models/address_model.dart';
import 'package:simp_token_app/models/date_model.dart';
import 'package:simp_token_app/models/notification_model.dart';
import 'package:simp_token_app/models/order_model.dart';
import 'package:simp_token_app/providers/cart_provider.dart';
import 'package:simp_token_app/providers/order_provider.dart';
import 'package:simp_token_app/providers/user_provider.dart';
import 'package:simp_token_app/utils/constants.dart';
import 'package:simp_token_app/utils/helper_functions.dart';
import 'package:simp_token_app/utils/image_constants.dart';
import 'package:simp_token_app/utils/sizedboxes.dart';
import 'package:simp_token_app/utils/theme.dart';

import 'order_successful_page.dart';

class CheckoutPage extends StatefulWidget {
  final String? pID;
  static const String routeName = '/checkout';

  CheckoutPage({Key? key, this.pID}) : super(key: key);

  @override
  State<CheckoutPage> createState() => _CheckoutPageState();
}

class _CheckoutPageState extends State<CheckoutPage> {
  late OrderProvider orderProvider;
  late CartProvider cartProvider;
  late UserProvider userProvider;
  final addressLine1Controller = TextEditingController();
  final addressLine2Controller = TextEditingController();
  final zipController = TextEditingController();
  String? city;
  String paymentMethodGroupValue = PaymentMethod.cod;

  @override
  void didChangeDependencies() {
    orderProvider = Provider.of<OrderProvider>(context, listen: true);
    cartProvider = Provider.of<CartProvider>(context, listen: false);
    userProvider = Provider.of<UserProvider>(context, listen: false);
    setAddressIfExists();
    super.didChangeDependencies();
  }

  @override
  Widget build(BuildContext context) {
    final localization = Provider.of<MyLocalization>(context);
    return Scaffold(
      backgroundColor: SimpTokenColorTheme().white,
      appBar: AppBar(
        toolbarHeight: 100,
        backgroundColor: SimpTokenColorTheme().white,
        automaticallyImplyLeading: true,
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              child: Image.asset(
                AppConstants.appLogo1,
                fit: BoxFit.fitHeight,
                width: 200,
              ),
            ),
            Text(
              localization.translate("checkout"),
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
            )
          ],
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(9),
        children: [
          buildHeader(
            localization.translate("product_info"),
          ),
          buildProductInfoSection(),
          SizedBoxes.verticalMicro,
          buildHeader(localization.translate("order_summary")),
          buildOrderSummarySection(localization),
          SizedBoxes.verticalMicro,
          buildHeader(
            localization.translate("delivery_address"),
          ),
          buildDeliveryAddressSection(localization),
          SizedBoxes.verticalMicro,
          buildHeader(
            localization.translate("payment_method"),
          ),
          buildPaymentMethodSection(),
          SizedBoxes.verticalMicro,
          buildOrderButtonSection(localization),
        ],
      ),
    );
  }

  Padding buildHeader(String header) {
    return Padding(
      padding: const EdgeInsets.all(8),
      child: Text(
        "${header} :",
        style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
      ),
    );
  }

  Widget buildProductInfoSection() {
    return Card(
      elevation: 5.0,
      child: Padding(
        padding: const EdgeInsets.all(8),
        child: Column(
          children: cartProvider.cartList
              .map((cartModel) => ListTile(
                    title: Text(
                      cartModel.productName,
                      style:
                          TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                    ),
                    trailing: Text(
                      '${cartModel.quantity} x ${cartModel.salePrice}',
                      style:
                          TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
                    ),
                  ))
              .toList(),
        ),
      ),
    );
  }

  Widget buildOrderSummarySection(localization) {
    return Card(
      elevation: 5.0,
      child: Padding(
        padding: const EdgeInsets.all(8),
        child: Column(
          children: [
            ListTile(
              title: Text(
                localization.translate("sub_total"),
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
              ),
              trailing:
                  Text('$currencySymbol${cartProvider.getCartSubTotal()}'),
            ),
            ListTile(
              title: Text(
                localization.translate("discount"),
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
              ),
              trailing: Text('0%'),
            ),
            ListTile(
              title: Text(
                localization.translate("vat"),
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
              ),
              trailing: Text('0%'),
            ),
            ListTile(
              title: Text(
                localization.translate("delivery_charge"),
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
              ),
              trailing: Text('0%'),
            ),
            const Divider(
              height: 2,
              color: Colors.black,
            ),
            ListTile(
              title: Text(
                localization.translate("grand_total"),
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17),
              ),
              trailing: Text(
                '$currencySymbol${orderProvider.getGrandTotal(cartProvider.getCartSubTotal())}',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget buildDeliveryAddressSection(localization) {
    return Card(
      elevation: 5.0,
      child: Padding(
        padding: const EdgeInsets.all(8),
        child: Column(
          children: [
            TextField(
              controller: addressLine1Controller,
              decoration: InputDecoration(
                hintText: localization.translate("address_line_1"),
              ),
            ),
            TextField(
              controller: addressLine2Controller,
              decoration: InputDecoration(
                hintText: localization.translate("address_line_2"),
              ),
            ),
            TextField(
              controller: zipController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                hintText: localization.translate("zip_code"),
              ),
            ),
            DropdownButton<String>(
              value: city,
              isExpanded: true,
              hint: Text(
                localization.translate("select_your_city"),
              ),
              items: cities
                  .map((city) => DropdownMenuItem<String>(
                        value: city,
                        child: Text(city),
                      ))
                  .toList(),
              onChanged: (value) {
                setState(() {
                  city = value;
                });
              },
            ),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    addressLine1Controller.dispose();
    addressLine2Controller.dispose();
    zipController.dispose();
    super.dispose();
  }

  Widget buildPaymentMethodSection() {
    return Card(
      elevation: 5.0,
      child: Padding(
        padding: const EdgeInsets.all(8),
        child: Row(
          children: [
            Radio<String>(
              value: PaymentMethod.cod,
              groupValue: paymentMethodGroupValue,
              onChanged: (value) {
                setState(() {
                  paymentMethodGroupValue = value!;
                });
              },
            ),
            const Text(PaymentMethod.cod),
          ],
        ),
      ),
    );
  }

  Widget buildOrderButtonSection(localization) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
      child: ReUsableButton(
        title: localization.translate("place_order"),
        onTap: () {
          _saveOrder();
        },
      ),
    );
  }

  Future<void> _saveOrder() async {
    if (addressLine1Controller.text.isEmpty) {
      showMsg(context, "Please provide address line 1");
      return;
    }
    if (zipController.text.isEmpty) {
      showMsg(context, "Please provide zipcode");
      return;
    }
    if (city == null) {
      showMsg(context, "Please provide your city");
      return;
    }
    EasyLoading.show(status: 'Please Wait');
    final orderModel = OrderModel(
      orderId: generateOrderId,
      userId: AuthService.currentUser!.uid,
      orderStatus: OrderStatus.pending,
      paymentMethod: paymentMethodGroupValue,
      grandTotal: orderProvider.getGrandTotal(cartProvider.getCartSubTotal()),
      orderDate: DateModel(
        timestamp: Timestamp.fromDate(DateTime.now()),
        day: DateTime.now().day,
        month: DateTime.now().month,
        year: DateTime.now().year,
      ),
      deliveryAddress: AddressModel(
          addressLine1: addressLine1Controller.text,
          addressLine2: addressLine2Controller.text,
          zipcode: zipController.text,
          city: city),
      productDetails: cartProvider.cartList,
    );

    try {
      await orderProvider.saveOrder(orderModel);

      final notification = NotificationModel(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        type: NotificationType.order,
        message: 'You have a new order #${orderModel.orderId}',
        orderModel: orderModel,
      );
      await orderProvider.addNotification(notification);
      EasyLoading.dismiss();
      if (mounted) {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => OrderSuccessfulPage(prodID: widget.pID),
          ),
        );
      }
    } catch (error) {
      EasyLoading.dismiss();
      showMsg(context, "You need to signin to place the order");
    }
  }

  void setAddressIfExists() {
    final userModel = userProvider.userModel;
    if (userModel != null) {
      if (userModel.addressModel != null) {
        final address = userModel.addressModel!;
        addressLine1Controller.text = address.addressLine1!;
        addressLine2Controller.text = address.addressLine2!;
        zipController.text = address.zipcode!;
        city = address.city;
      }
    }
  }
}
