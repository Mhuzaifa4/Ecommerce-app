import 'package:flutter/material.dart';

class ContactUs extends StatelessWidget {
    static const String routeName = '/contactus';

  const ContactUs({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      
    );
  }
}