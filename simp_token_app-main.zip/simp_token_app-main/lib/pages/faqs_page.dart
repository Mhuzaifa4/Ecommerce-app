import 'package:flutter/material.dart';
import 'package:simp_token_app/utils/image_constants.dart';
import 'package:simp_token_app/utils/theme.dart';

class FAQsPage extends StatelessWidget {
  static const String routeName = '/faqs';

  const FAQsPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        toolbarHeight: 100,
        backgroundColor: SimpTokenColorTheme().white,
        automaticallyImplyLeading: true,
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              child: Image.asset(
                AppConstants.appLogo1,
                fit: BoxFit.fitHeight,
                width: 200,
              ),
            ),
            const Text(
              "FAQ's",
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
            )
          ],
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: FAQList(),
      ),
    );
  }
}

class FAQList extends StatefulWidget {
  @override
  _FAQListState createState() => _FAQListState();
}

class _FAQListState extends State<FAQList> {
  List<FAQItem> faqs = [
    FAQItem(
        question: "RETURNS - HOW DOES IT WORK?",
        answer:
            "You have the option to return your order or individual items to us within 14 days of receiving your package. Please ensure the items are unworn, have the tag attached and are in their original packaging. You are responsible for the return shipping costs. We recommend insured shipping with tracking. After receiving and checking your return, we will refund the money to the payment method you chose, usually within a few days."),
    FAQItem(question: "RETURN ADDRESS:", answer: """Pepe & Lino
71522 Backnang, Germany"""),
    FAQItem(
        question: "EXCHANGE - HOW DOES IT WORK?",
        answer:
            "If you would like a garment in a different size, please return the item and place a new online order at the same time. Unfortunately, a direct exchange is not possible."),
    FAQItem(
        question: "DELIVERY TIMES - HOW LONG DOES IT TAKE?",
        answer:
            "We usually ship your order within 2 business days. The delivery time is usually 2-5 working days within Germany."),
    FAQItem(
        question: "THE NAME Pepe & Lino - WHAT DOES IT MEAN?",
        answer:
            "Pepe & Lino is a new creation made up of the Samoan word 'Pepe' (baby) and the word 'Lino'."),
    FAQItem(
        question:
            "Our garments usually correspond to standard sizes. if you are still unsure, don't hesitate to write us an small email. We are happy to provide personal advice",
        answer:
            "Pepe & Lino is a new creation made up of the Samoan word 'Pepe' (baby) and the word 'Lino'."),
    FAQItem(
        question: "PRODUCTION LOCATIONS - WHERE ARE THE CLOTHES MADE?",
        answer:
            "Pepe & Lino is a new creation made up of the Samoan word 'Pepe' (baby) and the word 'Lino'."),
    FAQItem(
        question:
            "Our collections are manufactured in small, family-run factories in Turkey.",
        answer:
            "Pepe & Lino is a new creation made up of the Samoan word 'Pepe' (baby) and the word 'Lino'."),
    FAQItem(
        question: "CARE OF YOUR CLOTHES - IMPORTANT NOTES",
        answer:
            "Each garment includes a care label with instructions. In general, we recommend gentle machine washing for cotton clothing at 30°C inside out. Please use detergent without optical brighteners and avoid the dryer. If you want to iron our clothes, do so inside out too. Avoid ironing directly over prints as they can come off. Wool should only be washed cold by hand. After washing, gently shape the garment and let it dry lying flat. If there is wool pilling, you can easily remove it with a brush or by hand. Pilling in wool products is inevitable."),
    FAQItem(
        question: "SIZES - HOW DO I FIND THE RIGHT ONE?",
        answer:
            "Our garments usually correspond to standard sizes. If you are still unsure, don't hesitate to write us an email. We are happy to provide personal advice."),
    // Add more FAQ items as needed
  ];

  @override
  Widget build(BuildContext context) {
    return ListView(
      children: faqs.map((faq) => FAQCard(faq: faq)).toList(),
    );
  }
}

class FAQItem {
  final String question;
  final String answer;

  FAQItem({required this.question, required this.answer});
}

class FAQCard extends StatelessWidget {
  final FAQItem faq;

  FAQCard({required this.faq});

  @override
  Widget build(BuildContext context) {
    return Card(
      color: SimpTokenColorTheme().logoColor,
      elevation: 2,
      margin: EdgeInsets.symmetric(vertical: 8),
      child: FAQExpansionTile(faq: faq),
    );
  }
}

class FAQExpansionTile extends StatelessWidget {
  final FAQItem faq;

  FAQExpansionTile({required this.faq});

  @override
  Widget build(BuildContext context) {
    return ExpansionTile(
      title: Text(
        faq.question,
        style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13),
      ),
      children: [
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: Text(
            faq.answer,
            style: TextStyle(
                fontWeight: FontWeight.w500, fontSize: 12, color: Colors.white),
          ),
        ),
      ],
    );
  }
}
