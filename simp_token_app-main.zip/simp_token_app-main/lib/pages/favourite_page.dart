import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:simp_token_app/customwidgets/locale.dart';
import 'package:simp_token_app/models/product_model.dart';
import 'package:simp_token_app/providers/favourite_provider.dart';

class FavouritePage extends StatelessWidget {
  static const String routeName = '/favourite';

  const FavouritePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final localization = Provider.of<MyLocalization>(context);

    return Scaffold(
      body: Consumer<FavouriteProvider>(
        builder: (context, favProvider, child) {
          if (favProvider.favoriteProducts.isEmpty) {
            return Center(
              child: Text(
                localization.translate("no_favorite_products_yet"),
              ),
            );
          }

          return ListView.builder(
            itemCount: favProvider.favoriteProducts.length,
            itemBuilder: (context, index) {
              ProductModel product =
                  favProvider.favoriteProducts.elementAt(index);

              return FavoriteProductCard(product: product);
            },
          );
        },
      ),
    );
  }
}

class FavoriteProductCard extends StatelessWidget {
  final ProductModel product;

  FavoriteProductCard({required this.product});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 3,
      margin: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: ListTile(
        contentPadding: EdgeInsets.all(16),
        leading: Image.network(
          product.thumbnailImageModel.imageDownloadUrl,
          width: 60,
          height: 60,
          fit: BoxFit.cover,
        ),
        title: Text(
          product.productName,
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ),
        trailing: Text(
          '\$${product.salePrice}',
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ),
        onTap: () {},
      ),
    );
  }
}
