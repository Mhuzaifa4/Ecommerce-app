import 'package:flutter/material.dart';
import 'package:simp_token_app/customwidgets/nav_bar_widget.dart';
import 'package:simp_token_app/pages/welcome_page.dart';
import 'package:simp_token_app/utils/image_constants.dart';
import '../auth/auth_service.dart';

class LauncherPage extends StatelessWidget {
  const LauncherPage({Key? key}) : super(key: key);
  static const String routeName = '/launcherpage';
  @override
  Widget build(BuildContext context) {
    Future.delayed(Duration(seconds: 3), () {
      if (AuthService.currentUser != null) {
        Navigator.pushReplacementNamed(context, MyBottomNavbar.routeName);
      } else {
        Navigator.pushReplacementNamed(context, WelcomePage.routeName);
      }
    });
    return Scaffold(
      body: Center(
          child: Image.asset(
        AppConstants.appLogo2,
        height: 300,
      )),
    );
  }
}
