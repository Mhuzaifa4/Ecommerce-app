import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:provider/provider.dart';
import 'package:simp_token_app/admin/adminPanel.dart';
import 'package:simp_token_app/customwidgets/locale.dart';
import 'package:simp_token_app/customwidgets/reusable_btn.dart';
import 'package:simp_token_app/customwidgets/text_field_widget.dart';
import 'package:simp_token_app/models/user_model.dart';
import 'package:simp_token_app/pages/signup_page.dart';
import 'package:simp_token_app/providers/user_provider.dart';
import 'package:simp_token_app/utils/sizedboxes.dart';
import 'package:simp_token_app/utils/theme.dart';
import '../auth/auth_service.dart';
import 'launcher_page.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({Key? key}) : super(key: key);
  static const String routeName = '/loginpage';

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final _formKey = GlobalKey<FormState>();
  String _errMsg = '';
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  late UserProvider userProvider;
  bool isAnonymous = false;
  bool obscureText = true;

  void togglePasswordVisibility() {
    setState(() {
      obscureText = !obscureText;
    });
  }

  @override
  void initState() {
    isAnonymous = AuthService.currentUser == null
        ? false
        : AuthService.currentUser!.isAnonymous;
    super.initState();
  }

  @override
  void didChangeDependencies() {
    userProvider = Provider.of<UserProvider>(context, listen: false);
    super.didChangeDependencies();
  }

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final localization = Provider.of<MyLocalization>(context);

    return Scaffold(
      body: Center(
          child: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          shrinkWrap: true,
          children: [
            Align(
              alignment: Alignment.center,
              child: Text(
                localization.translate("login_into_your_account"),
                style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
              ),
            ),
            SizedBoxes.verticalExtraGargangua,
            Text(
              localization.translate("email"),
              style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
            ),
            SizedBoxes.verticalMicro,
            CustomTextField(
                labelText: localization.translate("email"),
                controller: _emailController,
                prefixIcon: const Icon(Icons.email),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'This field must not be empty';
                  }
                  return null;
                }),
            SizedBoxes.verticalBig,
            Text(
              localization.translate("password"),
              style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
            ),
            SizedBoxes.verticalMicro,
            CustomTextField(
                labelText: localization.translate("password"),
                controller: _passwordController,
                obscureText: obscureText,
                prefixIcon: const Icon(Icons.password),
                suffixIcon: IconButton(
                  onPressed: togglePasswordVisibility,
                  icon: Icon(
                      obscureText ? Icons.visibility_off : Icons.visibility),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'This field must not be empty';
                  }
                  return null;
                }),
            SizedBoxes.verticalExtraGargangua,
            ReUsableButton(
              title: localization.translate("login"),
              onTap: () {
                _authenticate(true);
              },
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  localization.translate("dont_have_an_account"),
                ),
                TextButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => SignUpPage()),
                    );
                  },
                  child: Text(
                    localization.translate("sign_up"),
                    style: TextStyle(
                        color: SimpTokenColorTheme().primaryColor,
                        fontSize: 14,
                        fontWeight: FontWeight.bold),
                  ),
                ),
              ],
            ),
            SizedBoxes.verticalTiny,
            Text(
              _errMsg,
              style: const TextStyle(
                fontSize: 18,
                color: Colors.red,
              ),
            ),
          ],
        ),
      )),
    );
  }

  void _authenticate(bool tag, {UserModel? userm}) async {
    if (_formKey.currentState!.validate()) {
      EasyLoading.show(status: 'Please wait', dismissOnTap: false);
      final email = _emailController.text;
      final password = _passwordController.text;

      try {
        // Check if the entered credentials are for the admin
        bool isAdmin = await AuthService.checkAdminCredentials(email, password);

        if (isAdmin) {
          EasyLoading.dismiss();
          Navigator.pushReplacement(
              context, MaterialPageRoute(builder: (context) => AdminScreen()));
        } else {
          // Regular authentication process
          await AuthService.login(email, password);
          EasyLoading.dismiss();
          if (mounted) {
            Navigator.pushReplacementNamed(context, LauncherPage.routeName);
          }
        }
      } on FirebaseAuthException catch (error) {
        EasyLoading.dismiss();
        print('Error Code: ${error.code}');
        print('Error Message: ${error.message}');
        setState(() {
          _errMsg = error.message!;
        });
      }
    }
  }
}
