import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:simp_token_app/customwidgets/locale.dart';
import 'package:simp_token_app/models/cart_model.dart';
import 'package:simp_token_app/models/order_model.dart';
import 'package:simp_token_app/pages/returnRefund.dart';
import 'package:simp_token_app/providers/order_provider.dart';
import 'package:simp_token_app/utils/constants.dart';
import 'package:simp_token_app/utils/helper_functions.dart';
import 'package:simp_token_app/utils/sizedboxes.dart';

class OrderPage extends StatefulWidget {
  const OrderPage({Key? key}) : super(key: key);
  static const String routeName = '/orderpage';

  @override
  State<OrderPage> createState() => _OrderPageState();
}

class _OrderPageState extends State<OrderPage> {
  @override
  void initState() {
    super.initState();
    Provider.of<OrderProvider>(context, listen: false).getOrdersByUser();
  }

  @override
  Widget build(BuildContext context) {
    final localization = Provider.of<MyLocalization>(context);

    return SingleChildScrollView(
      child: Padding(
        padding: const EdgeInsets.only(left: 5, right: 5, top: 15),
        child: Column(
          children: Provider.of<OrderProvider>(context)
              .orderItemList
              .map<Widget>((item) => Card(
                    color: Colors.white,
                    elevation: 12.0,
                    margin: const EdgeInsets.symmetric(
                      horizontal: 10,
                      vertical: 5,
                    ),
                    child: Column(
                      children: [
                        GestureDetector(
                          onTap: () {     _showReturnRefundDialog(context, item.orderModel);

},

                          child: ListTile(
                            subtitle: Text(
                              getFormattedDate(
                                item.orderModel.orderDate.timestamp.toDate(),
                                pattern: 'dd/MM/yyyy HH:mm:ss',
                              ),
                            ),
                            title: Text(
                              localization.translate("order_placed_at"),
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 14,
                              ),
                            ),
                            trailing: Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 15, vertical: 4),
                              decoration: BoxDecoration(
                                color: Provider.of<OrderProvider>(context)
                                    .getOrderStatusColor(
                                        item.orderModel.orderStatus),
                                borderRadius: BorderRadius.circular(14),
                              ),
                              child: Text(
                                item.orderModel.orderStatus,
                                style: TextStyle(color: Colors.white),
                              ),
                            ),
                          ),
                        ),
                        const Divider(color: Colors.amber),
                        Column(
                          children:
                              item.orderModel.productDetails.map((cartModel) {
                            return Padding(
                                padding: EdgeInsets.symmetric(
                                    horizontal: 18, vertical: 10),
                                child: Column(
                                  children: [
                                    Row(children: [
                                      Text(
                                        localization.translate("quantity"),
                                        style: TextStyle(
                                            fontWeight: FontWeight.bold),
                                      ),
                                      const Spacer(),
                                      CircleAvatar(
                                        radius: 12,
                                        backgroundColor: Colors.amber,
                                        child: Text(
                                          '${cartModel.quantity}',
                                          style: const TextStyle(
                                            fontWeight: FontWeight.bold,
                                            color: Colors.white,
                                          ),
                                        ),
                                      )
                                    ]),
                                    SizedBoxes.verticalBig,
                                    Row(children: [
                                      Text(
                                        cartModel.productName,
                                        style: const TextStyle(
                                          fontWeight: FontWeight.bold,
                                          fontSize: 15,
                                        ),
                                      ),
                                      const Spacer(),
                                      Text(
                                        '${currencySymbol}${item.orderModel.grandTotal}',
                                        style: const TextStyle(
                                          fontWeight: FontWeight.bold,
                                          fontSize: 15,
                                        ),
                                      ),
                                    ]),
                                  ],
                                ));
                          }).toList(),
                        ),
                      ],
                    ),
                  ))
              .toList(),
        ),
      ),
    );
  }
  void _showReturnRefundDialog(BuildContext context, OrderModel orderModel) {
     if (orderModel.orderStatus == 'Cancelled') {
    // Do not proceed if the order status is "cancelled"
    return;
  }
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return AlertDialog(
        title: Text('Return or Refund'),
        content: Text('Do you want to return or refund the product?'),
        actions: <Widget>[
          TextButton(
            onPressed: () {
              // Navigate to the Return page
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                  builder: (context) => HelpAndFeedBack(
                    orderModel: orderModel,
                    cartModel: orderModel.productDetails.isNotEmpty
                        ? orderModel.productDetails.first
                        : CartModel(
                            productId: 'defaultProductId',
                            productName: 'Default Product',
                            productImageUrl: 'defaultImageUrl',
                            salePrice: 0.0,
                            stock: 0,
                          ),
                  ),
                ),
              );
              
            },
            child: Text('Yes'),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
            },
            child: Text('No'),
          ),
        ],
      );
    },
  );
}
}
