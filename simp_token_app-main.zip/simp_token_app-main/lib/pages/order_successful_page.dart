import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:provider/provider.dart';
import 'package:simp_token_app/auth/auth_service.dart';
import 'package:simp_token_app/customwidgets/locale.dart';
import 'package:simp_token_app/customwidgets/nav_bar_widget.dart';
import 'package:simp_token_app/providers/nav_bar_controller.dart';
import 'package:simp_token_app/providers/order_provider.dart';
import 'package:simp_token_app/providers/product_provider.dart';
import 'package:simp_token_app/providers/user_provider.dart';
import 'package:simp_token_app/utils/helper_functions.dart';

class OrderSuccessfulPage extends StatefulWidget {
  final String? prodID;
  static const String routeName = '/order_successful';

  OrderSuccessfulPage({Key? key, this.prodID}) : super(key: key);

  @override
  _OrderSuccessfulPageState createState() => _OrderSuccessfulPageState();
}

class _OrderSuccessfulPageState extends State<OrderSuccessfulPage> {
  double userRating = 0.0;

  @override
  void initState() {
    super.initState();
    navigateToOrderPageAfterDelay();
  }

  void navigateToOrderPageAfterDelay() {
    Future.delayed(const Duration(seconds: 3), () {
      Provider.of<BottomNavBarController>(context, listen: false)
          .changeScreen(3);
      Navigator.pushReplacementNamed(context, MyBottomNavbar.routeName);
      Provider.of<OrderProvider>(context, listen: false).getOrdersByUser();
    });
  }

  @override
  Widget build(BuildContext context) {
    final localization = Provider.of<MyLocalization>(context);
    ProductProvider productProvider =
        Provider.of<ProductProvider>(context, listen: false);

    Future.delayed(const Duration(seconds: 3), () {
      void showRateProductDialogAfterDelay() {
        showDialog(
          context: context,
          builder: (context) => AlertDialog(
            title: const Text("Please rate this product."),
            content: Consumer<UserProvider>(
              builder: (context, userProvider, child) {
                return Padding(
                  padding: const EdgeInsets.all(4),
                  child: RatingBar.builder(
                    itemSize: 20,
                    initialRating: 3.0,
                    minRating: 0.0,
                    direction: Axis.horizontal,
                    allowHalfRating: true,
                    itemCount: 5,
                    ignoreGestures: false,
                    itemPadding: const EdgeInsets.symmetric(horizontal: 0.0),
                    itemBuilder: (context, _) => const Icon(
                      Icons.star,
                      color: Colors.amber,
                    ),
                    onRatingUpdate: (rating) async {
                      userRating = rating;

                      final usersProvider =
                          Provider.of<UserProvider>(context, listen: false);

                      if (usersProvider.userModel == null) {
                        showMsg(context, 'Sign in to rate the product');
                        Navigator.pop(context);

                        return;
                      }

                      if (AuthService.currentUser!.isAnonymous) {
                      } else {
                        EasyLoading.show(status: 'Please wait');
                        await productProvider.addRating(
                          widget.prodID!,
                          userRating,
                          usersProvider.userModel!,
                        );
                        EasyLoading.dismiss();
                        Navigator.pop(context);
                        if (mounted) {
                          showMsg(context, 'Thanks for your rating');
                          Navigator.pop(context);
                          navigateToOrderPageAfterDelay();
                          Navigator.pop(context);
                        } else {
                          EasyLoading.dismiss();
                          if (mounted)
                            showMsg(
                                context, 'User information is not available.');
                        }
                      }
                    },
                  ),
                );
              },
            ),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.pop(context);

                  navigateToOrderPageAfterDelay();
                },
                child: Text("Later"),
              ),
            ],
          ),
        );
      }

      showRateProductDialogAfterDelay();
    });

    return Scaffold(
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(
              Icons.done,
              color: Colors.green,
              size: 150,
            ),
            Text(
              localization.translate("order_has_been_placed"),
            ),
          ],
        ),
      ),
    );
  }
}
