import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:provider/provider.dart';
import 'package:simp_token_app/customwidgets/reusable_btn.dart';
import 'package:simp_token_app/providers/cart_provider.dart';
import 'package:simp_token_app/providers/favourite_provider.dart';
import 'package:simp_token_app/providers/user_provider.dart';
import 'package:simp_token_app/utils/helper_functions.dart';
import 'package:simp_token_app/utils/sizedboxes.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../models/product_model.dart';
import '../providers/product_provider.dart';
import '../utils/constants.dart';

class ProductDetailsPage extends StatefulWidget {
  static const String routeName = '/productdetails';

  ProductDetailsPage({Key? key}) : super(key: key);

  @override
  State<ProductDetailsPage> createState() => _ProductDetailsPageState();
}

class _ProductDetailsPageState extends State<ProductDetailsPage> {
  late ProductModel productModel;
  late ProductProvider productProvider;
  late UserProvider userProvider;
  late FavouriteProvider favouriteProvider;
  late Size size;
  String photoUrl = '';
  double userRating = 0.0;
  bool isInCart = false;
  bool isFavorite = false;
  final TextEditingController txtController = TextEditingController();
  final FocusNode focusNode = FocusNode();

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    size = MediaQuery.of(context).size;
    productProvider = Provider.of<ProductProvider>(context, listen: false);
    userProvider = Provider.of<UserProvider>(context, listen: false);
    favouriteProvider = Provider.of<FavouriteProvider>(context, listen: false);
    productModel = ModalRoute.of(context)!.settings.arguments as ProductModel;
    photoUrl = productModel.thumbnailImageModel.imageDownloadUrl;
    isFavorite = favouriteProvider.isProductInFavorites(productModel);
  }

  @override
  Widget build(BuildContext context) {
    final usersProvider =
        Provider.of<UserProvider>(context, listen: false).getUserInfo();
    return Scaffold(
      appBar: AppBar(
        title: Text(
          productModel.productName,
          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
        ),
        centerTitle: true,
      ),
      body: ListView(
        children: [
          GestureDetector(
            onTap: () {
              showDialog(
                context: context,
                builder: (context) => Dialog(
                  child: CachedNetworkImage(
                    width: double.infinity,
                    height: 400,
                    fit: BoxFit.cover,
                    imageUrl: photoUrl,
                    placeholder: (context, url) =>
                        Center(child: CircularProgressIndicator()),
                    errorWidget: (context, url, error) => Icon(Icons.error),
                  ),
                ),
              );
            },
            child: CachedNetworkImage(
              width: double.infinity,
              height: 200,
              fit: BoxFit.cover,
              imageUrl: photoUrl,
              placeholder: (context, url) =>
                  const Center(child: CircularProgressIndicator()),
              errorWidget: (context, url, error) => const Icon(Icons.error),
            ),
          ),
          Row(
            children: [
              InkWell(
                onTap: () {
                  setState(() {
                    photoUrl =
                        productModel.thumbnailImageModel.imageDownloadUrl;
                  });
                },
                child: Card(
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(12),
                    child: CachedNetworkImage(
                      width: 70,
                      height: 90,
                      fit: BoxFit.fill,
                      imageUrl:
                          productModel.thumbnailImageModel.imageDownloadUrl,
                      placeholder: (context, url) =>
                          const Center(child: CircularProgressIndicator()),
                      errorWidget: (context, url, error) =>
                          const Icon(Icons.error),
                    ),
                  ),
                ),
              ),
              ...productModel.additionalImageModels.map((url) {
                return url.isEmpty
                    ? const SizedBox()
                    : InkWell(
                        onTap: () {
                          setState(() {
                            photoUrl = url;
                          });
                        },
                        child: Card(
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12)),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(12),
                            child: CachedNetworkImage(
                              width: 70,
                              height: 90,
                              fit: BoxFit.fill,
                              imageUrl: url,
                              placeholder: (context, url) => const Center(
                                  child: CircularProgressIndicator()),
                              errorWidget: (context, url, error) =>
                                  const Icon(Icons.error),
                            ),
                          ),
                        ),
                      );
              }).toList(),
              const Spacer(),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Consumer<FavouriteProvider>(
                    builder: (context, provider, child) {
                      return IconButton(
                        icon: Icon(
                          isFavorite ? Icons.favorite : Icons.favorite_border,
                          color: isFavorite ? Colors.red : null,
                        ),
                        onPressed: () async {
                          EasyLoading.show(status: "Please wait");

                          if (isFavorite) {
                            favouriteProvider.removeFromFavorites(productModel);
                            if (mounted)
                              showMsg(context, "Removed from Favourites");
                          } else {
                            favouriteProvider.addToFavorites(productModel);
                            if (mounted)
                              showMsg(context, "Added to Favourites");
                          }

                          setState(() {
                            isFavorite = !isFavorite;
                          });

                          EasyLoading.dismiss();
                          provider.notifyListeners();
                        },
                      );
                    },
                  ),
                  Row(
                    children: [
                      RatingBar.builder(
                        initialRating: productModel.avgRating.toDouble(),
                        minRating: 0.0,
                        direction: Axis.horizontal,
                        allowHalfRating: true,
                        itemCount: 1,
                        ignoreGestures: true,
                        itemSize: 20,
                        itemPadding:
                            const EdgeInsets.symmetric(horizontal: 0.0),
                        itemBuilder: (context, _) => const Icon(
                          Icons.star,
                          color: Colors.amber,
                        ),
                        onRatingUpdate: (rating) {
                          print(rating);
                        },
                      ),
                      Text(" ${productModel.avgRating.toStringAsFixed(1)}")
                    ],
                  )
                ],
              ),
              SizedBoxes.horizontalMedium
            ],
          ),
          const Divider(),
          Row(
            children: [
              const Padding(
                padding: EdgeInsets.only(left: 20),
                child: Text(
                  "Title",
                  style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold),
                ),
              ),
              Spacer(),
              Padding(
                padding: const EdgeInsets.only(right: 20),
                child: Text(
                  productModel.productName,
                  style: const TextStyle(
                      fontSize: 17, fontWeight: FontWeight.bold),
                ),
              ),
            ],
          ),
          SizedBoxes.verticalMedium,
          const Padding(
            padding: EdgeInsets.only(left: 20),
            child: Text(
              "Description",
              style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(left: 20),
            child: Text(
              productModel.longDescription!,
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w400,
                color: Colors.grey.shade400,
              ),
            ),
          ),
          SizedBoxes.verticalBig,
          Consumer<CartProvider>(
            builder: (context, provider, child) {
              final isInCart =
                  provider.isProductInCart(productModel.productId!);
              final buttonText = isInCart ? "Remove from Cart" : "Add to Cart";

              return Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: ReUsableButton(
                  title: buttonText,
                  onTap: () async {
                    EasyLoading.show(status: "Please wait");
                    final cartProvider =
                        Provider.of<CartProvider>(context, listen: false);
                    Provider.of<CartProvider>(context, listen: false)
                        .getAllCartItemsByUser();

                    if (isInCart) {
                      await cartProvider
                          .removeFromCart(productModel.productId!);
                      if (mounted) showMsg(context, "Removed from Cart");
                    } else {
                      await cartProvider.addToCart(
                          productId: productModel.productId!,
                          productName: productModel.productName,
                          url:
                              productModel.thumbnailImageModel.imageDownloadUrl,
                          salePrice: num.parse(getPriceAfterDiscount(
                            productModel.salePrice,
                            productModel.productDiscount,
                          )),
                          stock: productModel.stock);

                      if (mounted) showMsg(context, "Added to Cart");
                    }

                    EasyLoading.dismiss();
                  },
                ),
              );
            },
          ),
          SizedBoxes.verticalMedium,
          const Divider(),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Row(
              children: [
                const Text(
                  "Price:",
                  style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                ),
                const Spacer(),
                Text(
                  '$currencySymbol${productProvider.priceAfterDiscount(productModel.salePrice, productModel.productDiscount)}',
                  style: const TextStyle(
                      fontSize: 22, fontWeight: FontWeight.bold),
                ),
              ],
            ),
          ),
          SizedBoxes.verticalMedium,
        ],
      ),
    );
  }

  @override
  void dispose() {
    txtController.dispose();
    super.dispose();
  }
}
