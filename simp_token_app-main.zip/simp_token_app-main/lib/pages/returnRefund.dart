// ignore: file_names

// ignore_for_file: avoid_print

import 'dart:io';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
 import 'package:image_picker/image_picker.dart';
import 'package:dotted_border/dotted_border.dart';
import 'package:simp_token_app/models/cart_model.dart';
import 'package:simp_token_app/models/order_model.dart';
  import 'package:simp_token_app/utils/theme.dart'; 
import 'package:cloud_firestore/cloud_firestore.dart';


class HelpAndFeedBack extends StatefulWidget {
   final OrderModel orderModel;
    final CartModel cartModel;

  const HelpAndFeedBack({Key? key, required this.orderModel, required this.cartModel}) : super(key: key);

  @override
  State<HelpAndFeedBack> createState() => _HelpAndFeedBackState();
}

Map<String, File?> userfeedbackImage = {};

// ignore: non_constant_identifier_names
Future<File?> Image() async {
  final picker = ImagePicker();
  XFile? pickedFile = await picker.pickImage(source: ImageSource.gallery);

  if (pickedFile != null) {
    print('Picked profile image path: ${pickedFile.path}');
    return File(pickedFile.path);
  } else {
    print('Profile image picking canceled or failed.');
    return null;
  }
}

class _HelpAndFeedBackState extends State<HelpAndFeedBack> {



   final TextEditingController bankNameController = TextEditingController();
  final TextEditingController accountNumberController = TextEditingController();
  final TextEditingController beneficiaryNameController = TextEditingController();
  final TextEditingController reasonController = TextEditingController();

  bool validateForm() {
  if (bankNameController.text.isEmpty ||
      accountNumberController.text.isEmpty ||
      beneficiaryNameController.text.isEmpty ||
      reasonController.text.isEmpty ||
      userfeedbackImage.isEmpty) {
    // Return false if any of the fields or image is not filled
    return false;
  }
  return true;
}
Future<void> uploadDataToFirebase() async {
  try {
    CircularProgressIndicator();
    // Get a reference to the Refund collection
    CollectionReference refundCollection =
        FirebaseFirestore.instance.collection('Refund');

    // Upload images
    List<String> imageUrls = [];

    for (String key in userfeedbackImage.keys) {
      File? imageFile = userfeedbackImage[key];
      if (imageFile != null) {
        // Use the key as a unique identifier for each image
        String imageName =
            'refund_${DateTime.now().millisecondsSinceEpoch}.png';

        // Upload the image to Firebase Storage
        TaskSnapshot snapshot = await FirebaseStorage.instance
            .ref('images/$imageName')
            .putFile(imageFile);

        // Get the download URL of the uploaded image
        String imageUrl = await snapshot.ref.getDownloadURL();
        imageUrls.add(imageUrl); // Add the URL to the list

        // Print the image URL for debugging (optional)
        print('Image URL: $imageUrl');
      }
    }

    // Save the download URLs list in Firestore
    DocumentReference refundDocRef = await refundCollection.add({
      'orderId': widget.orderModel.orderId,
      'productName': widget.cartModel.productName,
      'orderPrice': widget.orderModel.grandTotal,
      'bankName': bankNameController.text,
      'accountNumber': accountNumberController.text,
      'beneficiaryName': beneficiaryNameController.text,
      'reason': reasonController.text,
      'images': imageUrls, // Save the list of download URLs
    });

    // Update the order status to "Return Requested"
    await FirebaseFirestore.instance
        .collection('Order')
        .doc(widget.orderModel.orderId)
        .update({'orderStatus': 'Return Requested'});

    // Clear the userfeedbackImage map after uploading images
    userfeedbackImage.clear();

    // Dispose the images (optional - you may not need this step)
    for (File? imageFile in userfeedbackImage.values) {
      imageFile?.delete();
    }

    Navigator.pop(context);
    print('Data uploaded to Firebase successfully!');
  } catch (error) {
    print('Error uploading data to Firebase: $error');
  }
}



  void removePetImageByKey(String key) {
    setState(() {
      if (userfeedbackImage.containsKey(key)) {
        userfeedbackImage.remove(key);
      }
    });
  }

  Widget imageCards(BuildContext context, String key) {
    bool isSelected = userfeedbackImage.containsKey(key);

    return SizedBox(
      width: 117,
      height: 123,
      child: Stack(
        clipBehavior: Clip.none,
        alignment: Alignment.topRight,
        children: [
          Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.all(Radius.circular(12)),
              image: DecorationImage(
                image: userfeedbackImage[key] != null
                    ? FileImage(userfeedbackImage[key]!)
                    : const AssetImage("assets/images/Discover1.png")
                        as ImageProvider,
                fit: BoxFit.cover,
              ),
            ),
          ),
          if (isSelected)
            Container(
              width: double.infinity,
              height: double.infinity,
              decoration: BoxDecoration(
                color: Colors.black.withOpacity(0.5), // Dark overlay
                borderRadius: BorderRadius.all(Radius.circular(12)),
              ),
            ),
          GestureDetector(
            onTap: () {
              removePetImageByKey(key);
              print("imagecard tapped");
            },
            child: Center(
              child: Text(
                "X",
                style: TextStyle(
                  color: isSelected ? Colors.white : Colors.transparent,
                  fontSize: 30,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    
    return Scaffold(
      
     appBar: AppBar(
       
        backgroundColor: SimpTokenColorTheme().white,
        automaticallyImplyLeading: true,
        title: Text(
         "Return And Refund",
        style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
                    ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Container(
            width: double.infinity,
            decoration: BoxDecoration(
              borderRadius: const BorderRadius.only(
                  topLeft: Radius.circular(15), topRight: Radius.circular(15)),
            
            ),
            child: Padding(
              padding: const EdgeInsets.all(12.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
               Container(
  height: 50,
  width: 300,
  decoration: BoxDecoration(
    border: Border.all(color: Colors.grey), // Border color
    borderRadius: BorderRadius.circular(8), // Border radius
  ),
  padding: const EdgeInsets.symmetric(horizontal: 12), // Adjust padding as needed
  child: Row(
    children: [
        
      const SizedBox(width: 8),
      Text("Order id:", style: TextStyle(color: Colors.grey),),
       const SizedBox(width: 8),
      Text(
        widget.orderModel.orderId,
        style: TextStyle(color: Colors.grey), // Text color
      ),
    ],
  ),
)
,
SizedBox(height: 10,),
  Container(
  height: 50,
  width: 300,
  decoration: BoxDecoration(
    border: Border.all(color: Colors.grey), // Border color
    borderRadius: BorderRadius.circular(8), // Border radius
  ),
  padding: const EdgeInsets.symmetric(horizontal: 12), // Adjust padding as needed
  child: Row(
    children: [
         const SizedBox(width: 8),
      Text("Product Name:", style: TextStyle(color: Colors.grey),),
       const SizedBox(width: 8),
      Text(
              widget.cartModel. productName,

        style: TextStyle(color: Colors.grey), // Text color
      ),
    ],
  ),
)
,
SizedBox(height: 10,),
 Container(
  height: 50,
  width: 300,
  decoration: BoxDecoration(
    border: Border.all(color: Colors.grey), // Border color
    borderRadius: BorderRadius.circular(8), // Border radius
  ),
  padding: const EdgeInsets.symmetric(horizontal: 12), // Adjust padding as needed
  child: Row(
    children: [
        const SizedBox(width: 8),
      Text("Order Price:", style: TextStyle(color: Colors.grey),),
       const SizedBox(width: 8),
      Text(
        widget.orderModel.grandTotal.toString(),
        style: TextStyle(color: Colors.grey), // Text color
      ),
    ],
  ),
)

,
  FormFiel(
                    hintText: 'Type your Bank Name here...',
                    textFieldController: bankNameController,
                    textFieldWidth: 390,
                    textFieldHeight: 50,
                  ),
                  FormFiel(
                    hintText: 'Type your Account Number here...',
                    textFieldController: accountNumberController,
                    textFieldWidth: 390,
                    textFieldHeight: 50,
                  ),
                  FormFiel(
                    hintText: 'Type your Benificiary Name here...',
                    textFieldController: beneficiaryNameController,
                    textFieldWidth: 390,
                    textFieldHeight: 50,
                  ),
                 

                  FormFiel(
                    hintText: 'Type your reason here...',
                    textFieldController: reasonController,
                    textFieldWidth: 390,
                    textFieldHeight: 180,
                  ),
                  SizedBox(height: 10),
                  SizedBox(
                    width: 390,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Wrap(
                          alignment: WrapAlignment.spaceBetween,
                          spacing: 10,
                          runSpacing: 10,
                          children: [
                            for (String key in userfeedbackImage.keys)
                              imageCards(context, key),
                            GestureDetector(
                                onTap: () async {
                                  File? pickedImage = await Image();
                                  if (pickedImage != null) {
                                    String petImageKey =
                                        'card${userfeedbackImage.length}';
                                    userfeedbackImage[petImageKey] =
                                        pickedImage;
                                    setState(() {});
                                  }
                                },
                                child: DottedBorder(
                                    borderPadding: EdgeInsets.all(0.5),
                                    borderType: BorderType.RRect,
                                    radius: Radius.circular(14),
                                    child: ClipRRect(
                                        borderRadius: BorderRadius.all(
                                            Radius.circular(12)),
                                        child: Container(
                                          height: 123,
                                          width: 117,
                                          decoration: BoxDecoration(
                                            color: Color(0xFFDBE2EC),
                                            borderRadius:
                                                BorderRadius.circular(8),
                                            border: Border.all(
                                              color: Color(0xFFDBE2EC),

                                              style: BorderStyle.solid,
                                              width:
                                                  1.0, // You can adjust the width of the border
                                            ),
                                          ),
                                          child: Column(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              children: [
                                                Icon(
                                                  Icons.add_circle,
                                                
                                                ),
                                                SizedBox(height: 4),
                                                Text(
                                                  "Add more",
                                                  style: TextStyle(
                                                   
                                                  ),
                                                ),
                                              ]),
                                        ))))
                          ],
                        ),
                      ],
                    ),
                  ),

                  SizedBox(height: 170,),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: ElevatedButton(
                       onPressed: () {
      // Perform form validation before submitting
      if (validateForm()) {
        uploadDataToFirebase();
      } else {
        // Display an error message or take appropriate action
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Please fill in all the details'),
          ),
        );
      }
    },
                      style: ButtonStyle(
                       
                        fixedSize: MaterialStateProperty.all<Size>(
                            const Size(390, 55)),
                      ),
                      child: Text(
                        "Submit",
                      
                      ),
                    ),
                  ),
                  // 180.verticalSpace
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class FormFiel extends StatelessWidget {
  final TextEditingController textFieldController;
  final double textFieldWidth;
  final double textFieldHeight;
  final String? hintText; 

  const FormFiel({
    Key? key,
    required this.textFieldController,
    required this.textFieldWidth,
    required this.textFieldHeight,
    this.hintText, // Make the hint text optional
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(5.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 10),
          Container(
            width: textFieldWidth,
            height: textFieldHeight,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: const Color(0xFF8F9DB2)),
            ),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8.0),
              child: Padding(
                padding: const EdgeInsets.only(left: 12.0),
                child: TextField(
                  controller: textFieldController,
                  decoration: InputDecoration(
                      border: InputBorder.none,
                      hintText: hintText ?? '',
                      hintStyle: const TextStyle(
                          color: Color(0xFF9BA8BB), fontSize: 16)),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
 