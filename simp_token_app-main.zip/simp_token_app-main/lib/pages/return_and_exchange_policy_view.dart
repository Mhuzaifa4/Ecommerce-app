import 'package:flutter/material.dart';
import 'package:simp_token_app/utils/image_constants.dart';
import 'package:simp_token_app/utils/sizedboxes.dart';
import 'package:simp_token_app/utils/theme.dart';

class ReturnAndExchangePolicyView extends StatelessWidget {
  static const String routeName = '/return&exhangepolicy';

  const ReturnAndExchangePolicyView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        toolbarHeight: 100,
        backgroundColor: SimpTokenColorTheme().white,
        automaticallyImplyLeading: true,
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              child: Image.asset(
                AppConstants.appLogo1,
                fit: BoxFit.fitHeight,
                width: 200,
              ),
            ),
            const Text(
              "Return & Exchange Policy",
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
            )
          ],
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBoxes.verticalLarge,
              const Text(
                "RETURN AND EXCHANGE POLICY",
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
              ),
              SizedBoxes.vertical2Px,
              Text(
                """We understand that your preferences may change, so we accept returns within 14 days of receiving your order. Please see our detailed information on returns in our cancellation policy.

Please note that Pepe & Lino does not offer free returns. You bear the costs for the return.
          """,
                style: TextStyle(
                    fontWeight: FontWeight.w400,
                    fontSize: 12,
                    color: Colors.grey.shade500),
              ),
              // SizedBoxes.verticalTiny,
              const Text(
                "This is how the return works:",
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
              ),
              SizedBoxes.vertical2Px,
              Text(
                """The Pepe & Lino story began with a desire to create clothing for our own children that showcases their unique style and personality. As parents, we wanted to ensure that our little ones could wear comfortable, high-quality clothing that not only serves their comfort, but also aligns with our values ​​of sustainability and social responsibility.
                """,
                style: TextStyle(
                    fontWeight: FontWeight.w400,
                    fontSize: 12,
                    color: Colors.grey.shade500),
              ),

              const Text(
                "REFUNDS",
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
              ),
              SizedBoxes.vertical2Px,
              Text(
                """Once we receive your return, we will refund the corresponding amount. Refunds will be made to the original payment method used.
                """,
                style: TextStyle(
                    fontWeight: FontWeight.w400,
                    fontSize: 12,
                    color: Colors.grey.shade500),
              ),
              SizedBoxes.verticalMicro,

              const Text(
                "EXCHANGE",
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
              ),
              SizedBoxes.vertical2Px,
              Text(
                """If you would like an item in a different size, style or color, please place a new order and return the items you would like to exchange in accordance with the return policy.

""",
                style: TextStyle(
                    fontWeight: FontWeight.w400,
                    fontSize: 12,
                    color: Colors.grey.shade500),
              ),
              const Text(
                "DAMAGED ITEMS AND COMPLAINTS",
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
              ),
              SizedBoxes.vertical2Px,
              Text(
                """If you have received a damaged item or would like to make a complaint, please contact us immediately by email at the following addresses:

Damaged items: help@pepe-lino.de

Complaints: help@pepe-lino.de

""",
                style: TextStyle(
                    fontWeight: FontWeight.w400,
                    fontSize: 12,
                    color: Colors.grey.shade500),
              ),
              const Text(
                "SHIPPING: ",
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
              ),
              SizedBoxes.vertical2Px,
              Text(
                """Germany  € 3.50
For orders over € 70 (exclusively goods vouchers) we offer free shipping within Germany.
If the order value falls below €70 due to your return, we will charge the original shipping costs of €3.50.
EU countries  € 10.50
For an order value over € 100 (exclusively goods vouchers) we offer reduced shipping within the EU of € 6.
If the order value falls below €80 due to your return, we will charge the original shipping costs of €6.00.
(Austria, Belgium, Bulgaria, Croatia, Czech Republic, Denmark, Estonia, Finland, France, Greece, Hungary, Ireland, Italy, Latvia, Lithuania, Luxembourg, Malta, Netherlands, Poland, Portugal, Romania, Slovakia, Slovenia, Spain, Sweden)

Imprint
Pepe & Lino

71522 Backnang
Germany

Tel.: 017613895881
E-mail: info@pepe-lino.de

Registration court: Dortmund District Court
Registration number: HRB

Managing Directors: Ibrahim Kanat

VAT identification number:

Responsible person within the meaning of Section 18 Paragraph 2 MStV:
Ibrahim Kanat, 71522 Backnang, Germany

Right of withdrawal A. Instructions on withdrawal

*Introduction:*
Consumers who conclude a legal transaction for purposes that cannot be predominantly attributed to their commercial or independent professional activity are entitled to the following right of withdrawal:
*Right of withdrawal:* You have the right to withdraw within fourteen days without State reasons for revoking this contract. The cancellation period is fourteen days from the day on which you or a third party named by you who is not the carrier took possession of the last goods. In order to exercise your right of withdrawal, you must inform us (Pepe & Lino, 71522 Backnang, Germany, Tel.: 017613895881, Email: info@pepe-lino.de) by means of a clear statement (e.g. a letter sent by post or email) via the EU Commission's platform for online dispute resolution: https://ec.europa.eu/odr


We are neither obliged nor willing to participate in a dispute resolution procedure before a consumer arbitration board.

""",
                style: TextStyle(
                    fontWeight: FontWeight.w400,
                    fontSize: 12,
                    color: Colors.grey.shade500),
              ),

              SizedBoxes.verticalMicro,

              const Text(
                "Right of withdrawal",
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
              ),
              SizedBoxes.verticalTiny,

              const Text(
                "A. Cancellation policy",
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
              ),
              SizedBoxes.vertical2Px,
              Text(
                """*Introduction:*
Consumers who conclude a legal transaction for purposes that cannot predominantly be attributed to their commercial or independent professional activity are entitled to the following right of withdrawal:

*Right of withdrawal:*
You have the right to withdraw within fourteen days without giving reasons to revoke the contract. The cancellation period is fourteen days from the day on which you or a third party named by you who is not the carrier took possession of the last goods. In order to exercise your right of withdrawal, you must inform us (Pepe & Lino, 71522 Backnang, Germany, Tel.: 017613895881, Email: info@pepe-lino.de ) by means of a clear statement (e.g. a letter sent by post or email).

""",
                style: TextStyle(
                    fontWeight: FontWeight.w400,
                    fontSize: 12,
                    color: Colors.grey.shade500),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
