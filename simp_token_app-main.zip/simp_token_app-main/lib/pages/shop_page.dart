import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:simp_token_app/customwidgets/discount_alertDialog.dart';
import 'package:simp_token_app/customwidgets/locale.dart';
import 'package:simp_token_app/customwidgets/nav_bar_widget.dart';
import 'package:simp_token_app/customwidgets/product_grid_item_view.dart';
import 'package:simp_token_app/models/product_model.dart';
import 'package:simp_token_app/providers/product_provider.dart';
import '../models/category_model.dart';

class ShopPage extends StatefulWidget {
  static const String routeName = '/shoppage';

  final CategoryModel? selectedCategory;

  const ShopPage({Key? key, this.selectedCategory}) : super(key: key);

  @override
  _ShopPageState createState() => _ShopPageState();
}

class _ShopPageState extends State<ShopPage> {
  TextEditingController searchController = TextEditingController();
  String searchTerm = '';
  late MyLocalization localization;

  late CategoryModel? selectedCategorynew;

  // @override
  // void initState() {
  //   super.initState();
  //   showDiscountedItemsDialog(context, ProductProvider().productList);
  // }

  @override
  Widget build(BuildContext context) {
    selectedCategorynew = widget.selectedCategory;
    // selectedCategorynew= allProducts
    //     .where((product) =>
    // widget.selectedCategory!.categoryName == 'All' ||
    //     product.category.categoryName ==
    //         widget.selectedCategory!.categoryName)
    //     .toList();
    print("Shop Page opened");
    final localization = Provider.of<MyLocalization>(context);

    return Scaffold(
      appBar: AppBar(
        title: Text(
          localization.translate("shop"),
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Container(
              width: 200,
              child: TextField(
                controller: searchController,
                decoration: InputDecoration(
                  hintText: localization.translate("search_product"),
                ),
                onChanged: (value) {
                  setState(() {
                    searchTerm = value;
                  });
                },
              ),
            ),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.only(top: 40),
        child: Consumer<ProductProvider>(
          builder: (context, provider, child) {
            final allProducts = provider.productList;
            List<ProductModel> filteredProducts;
            if (widget.selectedCategory != null) {
              filteredProducts = allProducts
                  .where((product) =>
                      widget.selectedCategory!.categoryName == 'All' ||
                      product.category.categoryName ==
                          widget.selectedCategory!.categoryName)
                  .toList();
            } else {
              filteredProducts = allProducts;
            }

            if (searchTerm.isNotEmpty) {
              filteredProducts = filteredProducts
                  .where((product) => product.productName
                      .toLowerCase()
                      .contains(searchTerm.toLowerCase()))
                  .toList();
            }

            return GridView.builder(
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                childAspectRatio: (130.0 / 165.0),
                crossAxisCount: 2,
                crossAxisSpacing: 8.0,
                mainAxisSpacing: 8.0,
              ),
              itemCount: filteredProducts.length,
              itemBuilder: (context, index) {
                final product = filteredProducts[index];
                return ProductGridItemView(productModel: product);
              },
            );
          },
        ),
      ),
    );
  }

  @override
  void initState() {
    super.initState();
    // Delay the execution using Future.delayed
    Future.delayed(Duration.zero, () {
      // Access your inherited widget or Provider here
      // localization = Provider.of<MyLocalization>(context);
      // Rest of your initState logic
      // showDiscountedItemsDialog(context, ProductProvider().productList, widget.selectedCategory);
      // showDiscountedItemsDialog(context, ProductProvider().productList,selectedCategorynew!);
      List<ProductModel> plsit =
          Provider.of<ProductProvider>(context, listen: false).productList;
      // print(plsit.length);
      showDiscountedItemsDialog(
          context, plsit, selectedCategorynew!.categoryName);
    });
  }
}

// void showDiscountedItemsDialog(BuildContext context, List<ProductModel> discountedProducts,CategoryModel category) {
//
//   List<ProductModel> discountedProducts = Provider.of<ProductProvider>(context,listen: false).productList;
//
//   showDialog(
//     context: context,
//     builder: (context) {
//       return DiscountedItemsList(discountedProducts: discountedProducts, selectedCategory: category,);
//     },
//   );
// }

void showDiscountedItemsDialog(BuildContext context,
    List<ProductModel> discountedProducts, String? categoryName) {
  // List<ProductModel> filteredDiscountedProducts = FilterDiscountedProduct(discountedProducts, categoryName);
  print("IN showdiscounteditemdialog ${discountedProducts.length}");
  showDialog(
    context: context,
    builder: (context) {
      return DiscountedItemsList(
          discountedProducts: discountedProducts,
          selectedCategory: categoryName);
    },
  );
}
