// ignore_for_file: unused_local_variable

import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import 'package:simp_token_app/auth/auth_service.dart';
import 'package:simp_token_app/customwidgets/locale.dart';
import 'package:simp_token_app/customwidgets/reusable_btn.dart';
import 'package:simp_token_app/customwidgets/text_field_widget.dart';
import 'package:simp_token_app/models/user_model.dart';
import 'package:simp_token_app/pages/login_page.dart';
import 'package:simp_token_app/providers/signup_provider.dart';
import 'package:simp_token_app/providers/user_provider.dart';
import 'package:simp_token_app/utils/sizedboxes.dart';
import 'package:simp_token_app/utils/theme.dart';

class SignUpPage extends StatefulWidget {
  const SignUpPage({Key? key}) : super(key: key);
  static const String routeName = '/signuppage';

  @override
  _SignUpPageState createState() => _SignUpPageState();
}

class _SignUpPageState extends State<SignUpPage> {
  UserProvider userProvider = UserProvider();

  late SignUpController signUpController;

  final ImagePicker _picker = ImagePicker();
  File? selectedImage;

  @override
  void initState() {
    super.initState();
    signUpController = Provider.of<SignUpController>(context, listen: false);
  }

  getImage(ImageSource source) async {
    final XFile? image = await _picker.pickImage(source: source);
    if (image != null) {
      selectedImage = File(image.path);
      setState(() {});
    }
  }

  @override
  Widget build(BuildContext context) {
    final localization = Provider.of<MyLocalization>(context);

    return Scaffold(
      backgroundColor: SimpTokenColorTheme().white,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBoxes.verticalBig,
                Text(
                  localization.translate("create_your_account"),
                  style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold),
                ),
                SizedBoxes.verticalMedium,
                Padding(
                  padding: EdgeInsets.only(
                      top: MediaQuery.of(context).size.height * 0.01,
                      bottom: MediaQuery.of(context).size.height * 0.02),
                  child: Center(
                    child: InkWell(
                      onTap: () {
                        getImage(ImageSource.gallery);
                      },
                      child: selectedImage == null
                          ? Container(
                              width: 110,
                              height: 110,
                              margin: const EdgeInsets.only(bottom: 20),
                              decoration: const BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: Color(0xffD6D6D6)),
                              child: const Center(
                                child: Icon(
                                  Icons.camera_alt_outlined,
                                  size: 40,
                                  color: Colors.white,
                                ),
                              ),
                            )
                          : Container(
                              width: 110,
                              height: 110,
                              margin: const EdgeInsets.only(bottom: 20),
                              decoration: BoxDecoration(
                                  image: DecorationImage(
                                      image: FileImage(selectedImage!),
                                      fit: BoxFit.fill),
                                  shape: BoxShape.circle,
                                  color: const Color(0xffD6D6D6)),
                              child: Icon(
                                Icons.camera_alt,
                                size:
                                    MediaQuery.of(context).size.height * 0.032,
                                color: const Color(0xff171717),
                              ),
                            ),
                    ),
                  ),
                ),
                Text(
                  localization.translate("username"),
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w400,
                  ),
                ),
                SizedBoxes.verticalMedium,
                CustomTextField(
                  labelText: localization.translate("username"),
                  controller: signUpController.nameController,
                  prefixIcon: const Icon(Icons.email),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'This field must not be empty';
                    }
                    return null;
                  },
                ),
                SizedBoxes.verticalMedium,
                Text(
                  localization.translate("email"),
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w400,
                  ),
                ),
                SizedBoxes.verticalMedium,
                CustomTextField(
                  labelText: localization.translate("email"),
                  controller: signUpController.emailController,
                  prefixIcon: const Icon(Icons.email),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'This field must not be empty';
                    }
                    return null;
                  },
                ),
                SizedBoxes.verticalMedium,
                Text(
                  localization.translate("password"),
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w400,
                  ),
                ),
                SizedBoxes.verticalMedium,
                CustomTextField(
                  labelText: localization.translate("password"),
                  controller: signUpController.passwordController,
                  prefixIcon: const Icon(Icons.password),
                  obscureText: true, // Password is hidden
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'This field must not be empty';
                    }
                    return null;
                  },
                ),
                SizedBoxes.verticalBig,
                Center(
                  child: ReUsableButton(
                    title: localization.translate("sign_up"),
                    onTap: () {
                      _authenticate(false,
                          userm: UserModel(
                            userId: 'userId',
                            email: signUpController.emailController.text,
                            password: signUpController.passwordController.text,
                            displayName: signUpController.nameController.text,
                            imageUrl: selectedImage?.path ?? '',
                          ));
                    },
                  ),
                ),
                SizedBoxes.verticalBig,
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      localization.translate("already_have_account"),
                      style: TextStyle(color: Colors.grey.shade400),
                    ),
                    TextButton(
                      onPressed: () {
                        Navigator.pushReplacementNamed(
                            context, LoginPage.routeName);
                      },
                      child: Text(
                        localization.translate("sign_in"),
                        style: TextStyle(
                          color: SimpTokenColorTheme().primaryColor,
                          fontWeight: FontWeight.bold,
                          fontSize: 15,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _authenticate(bool tag, {UserModel? userm}) async {
    try {
      EasyLoading.show();

      if (AuthService.currentUser == null) {
        if (userm?.email != null && userm?.password != null) {
          await AuthService.register(
            userm!.email,
            userm.password!,
          );
        }
      }
      if (selectedImage != null) {
        final storageRef =
            FirebaseStorage.instance.ref().child('images/${userm!.userId}.jpg');
        await storageRef.putFile(selectedImage!);

        final imageUrl = await storageRef.getDownloadURL();

        if (imageUrl != null) {
          userm.imageUrl = imageUrl;
        }
      }
      if (!tag) {
        final userModel = UserModel(
          displayName: userm!.displayName,
          addressModel: userm.addressModel,
          imageUrl: userm.imageUrl,
          userId: AuthService.currentUser!.uid,
          email: AuthService.currentUser!.email!,
          userCreationTime: Timestamp.fromDate(
            AuthService.currentUser!.metadata.creationTime!,
          ),
        );

        await userProvider.addUser(userModel);

        EasyLoading.dismiss();
        Navigator.of(context).popUntil((route) => route.isFirst);
        Navigator.of(context).pushReplacementNamed('/launcherpage');
        setState(() {});
      }
    } on FirebaseAuthException catch (error) {
      EasyLoading.dismiss();

      setState(() {
        print('Firebase Auth Error: ${error.message}');
      });
    }
  }
}
