import 'package:flutter/material.dart';
import 'package:simp_token_app/utils/image_constants.dart';
import 'package:simp_token_app/utils/sizedboxes.dart';
import 'package:simp_token_app/utils/theme.dart';

class TermsAndConditionsPage extends StatelessWidget {
  static const String routeName = '/terms&conditions';

  const TermsAndConditionsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        toolbarHeight: 100,
        backgroundColor: SimpTokenColorTheme().white,
        automaticallyImplyLeading: true,
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              child: Image.asset(
                AppConstants.appLogo1,
                fit: BoxFit.fitHeight,
                width: 200,
              ),
            ),
            const Text(
              "Terms & Conditions",
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
            )
          ],
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBoxes.verticalLarge,
              const Text(
                """General terms and conditions with customer information

Table of contents:

1. Scope
2. Conclusion of contract
3. Right of withdrawal
4. Prices and payment conditions
5. Delivery and shipping conditions
6. Retention of title
7. Liability for defects (warranty)
8. Redemption of promotional vouchers
9. Redemption of gift vouchers
10. Applicable law
11 . Place of jurisdiction
12. Alternative dispute resolution
""",
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
              ),
              const Text(
                "1) Scope",
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
              ),
              SizedBoxes.vertical2Px,
              Text(
                """
1.1 These General Terms and Conditions (hereinafter "GTC") apply to all contracts for the delivery of goods that a customer (hereinafter "Customer") has with Pepe & Lino (hereinafter "Seller") with regard to goods presented in the seller's online shop. Any of the customer's own conditions are hereby excluded, unless expressly agreed otherwise.

1.2 These General Terms and Conditions also apply to contracts for the delivery of vouchers, unless different regulations have been made.

1.3 A consumer within the meaning of these General Terms and Conditions is any natural person who concludes the contract for purposes that cannot primarily be attributed to their commercial or independent professional activity.

1.4 An entrepreneur within the meaning of these General Terms and Conditions is a natural or legal person or a legal partnership that concludes the contract in the exercise of their commercial or independent professional activity.

          """,
                style: TextStyle(
                    fontWeight: FontWeight.w400,
                    fontSize: 12,
                    color: Colors.grey.shade500),
              ),
              const Text(
                "2) Conclusion of contract",
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
              ),
              SizedBoxes.vertical2Px,
              Text(
                """
2.1 The product descriptions in the seller's online shop do not represent binding offers, but only serve to enable the customer to submit a binding offer.

2.2 The customer can submit his offer via the online order form in the seller's online shop. By clicking the button that completes the ordering process, the customer makes a legally binding offer with regard to the goods contained in the shopping cart.

2.3 The seller can accept the customer's offer within five days:
   - by sending a written order confirmation or order confirmation in text form (e.g. by email), whereby the customer's receipt is decisive, or
   - by delivering the ordered goods to the Customers, whereby the receipt of the goods by the customer is decisive, or
   - by requesting payment after placing the order.

2.4The period for accepting the offer begins on the day after the customer sends the offer and ends at the end of the fifth day following the sending of the offer. If the seller does not accept the customer's offer within this period, this is considered a rejection of the offer and the customer is no longer bound by his declaration of intent.

2.5 If you select a payment method offered by PayPal, payment is processed via the payment service provider PayPal (Europe) S.à rl et Cie, SCA, 22-24 Boulevard Royal, L-2449 Luxembourg. Acceptance of the customer offer occurs when the customer completes the ordering process.

2.6 If you select the payment method “Amazon Payments”, payment will be processed via the payment service provider Amazon Payments Europe sca, 38 avenue John F. Kennedy, L-1855 Luxembourg. The customer offer is accepted by clicking the button that completes the ordering process.

2.7 The contract text is saved by the seller and sent to the customer in text form after the order has been sent. The customer can view the order data in the customer account, if one has been set up.

2.8 Before bindingly submitting the order, the customer can identify and correct possible input errors by carefully reading the information on the screen. An effective way to better detect input errors can be the browser's magnification function.

2.9 Order processing and contact are usually made via email. The customer must ensure that the email address they provide is correct in order to receive emails sent by the seller. 

         """,
                style: TextStyle(
                    fontWeight: FontWeight.w400,
                    fontSize: 12,
                    color: Colors.grey.shade500),
              ),
              const Text(
                "3) Right of withdrawal",
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
              ),
              SizedBoxes.vertical2Px,
              Text(
                """

3.1 Consumers have a right of withdrawal. Further information can be found in the seller's cancellation policy.

3.2 Further information on the right of withdrawal can be found in the seller's cancellation policy.

3.3 The right of withdrawal does not apply to consumers who do not belong to a member state of the European Union at the time the contract is concluded and whose sole place of residence and delivery address is outside the European Union at the time the contract is concluded.
4) Prices and terms of payment
4.1 Unless otherwise stated in the seller's product description, the prices stated are total prices that include statutory sales tax. Any additional delivery and shipping costs that may arise will be stated separately in the respective product description.
4.2 For deliveries to countries outside the European Union, additional costs may arise in individual cases for which the seller is not responsible and which must be borne by the customer. These include, for example, costs for transferring money through credit institutions (e.g. transfer fees, exchange rate fees) or import duties or taxes (e.g. customs duties). Such costs may arise in relation to the money transfer even if the delivery does not take place to a country outside the European Union but the customer makes the payment from a country outside the European Union.
4.3 The payment option(s) will be communicated to the customer in the seller's online shop.
4.4 If you select a payment method offered via the “PayPal” payment service, payment is processed via PayPal, although PayPal can also use the services of third-party payment service providers for this purpose. If the seller also offers payment methods via PayPal in which he makes advance payments to the customer (e.g. purchase on account or payment in installments), he assigns his payment claim to PayPal or to the payment service provider commissioned by PayPal and specifically named to the customer. Before accepting the seller's declaration of assignment, PayPal or the payment service provider commissioned by PayPal carries out a credit check using the customer data transmitted. The seller reserves the right to refuse the customer the selected payment method in the event of a negative check result. If the selected payment method is approved, the customer must pay the invoice amount within the agreed payment period or at the agreed payment intervals. In this case, he can only make payments to PayPal or the payment service provider commissioned by PayPal with a debt-discharging effect. However, even in the event of the assignment of claims, the seller remains responsible for general customer inquiries, e.g. B. about the goods, delivery time, shipping, returns, complaints, cancellation declarations and shipments or credit notes.
4.5 If you select a payment method offered via the payment service “Shopify Payments”, payment is processed via the payment service provider Stripe Payments Europe Ltd., 1 Grand Canal Street Lower, Grand Canal Dock, Dublin, Ireland (hereinafter “Stripe”). The individual payment methods offered via Shopify Payments are communicated to the customer in the seller's online shop. To process payments, Stripe may use other payment services to which special payment conditions may apply, to which the customer may be notified separately. Further information about “Shopify Payments” is available online at https://www.shopify.com/legal/terms-payments-de  .
4.6 If you select a payment method offered via the “Klarna” payment service, payment is processed via Klarna Bank AB (publ), Sveavägen 46, 111 34 Stockholm, Sweden (hereinafter “Klarna”). Further information and Klarna's conditions can be found in the seller's payment information, which can be viewed at the following internet address:
https://hejlenki.de/policies/terms-of-service
5) Delivery and shipping conditions
5.1 If the seller offers the If the goods are dispatched, delivery will take place within the delivery area specified by the seller to the delivery address specified by the customer, unless otherwise agreed.
     
          """,
                style: TextStyle(
                    fontWeight: FontWeight.w400,
                    fontSize: 12,
                    color: Colors.grey.shade500),
              ),
              // SizedBoxes.verticalTiny,
              const Text(
                "Shopify",
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
              ),
              SizedBoxes.vertical2Px,
              Text(
                """
Shopify Payments Terms of Service - Germany

Shopify's list of terms and conditions that apply to all users that access or use the Shopify API or any associated information or other data.

When processing the transaction, the delivery address specified in the seller's order processing is decisive.
5.2 If delivery of the goods fails for reasons for which the customer is responsible, the customer shall bear the reasonable costs incurred by the seller as a result. This does not apply with regard to the shipping costs if the customer effectively exercises his right of cancellation. If the customer effectively exercises the right of cancellation, the return shipping costs will be subject to the provisions set out in the seller's cancellation policy.
5.3 If the customer acts as an entrepreneur, the risk of accidental loss and accidental deterioration of the goods sold passes to the customer as soon as the seller has delivered the item to the freight forwarder, the freight carrier or the person or institution otherwise designated to carry out the shipment. If the customer acts as a consumer, the risk of accidental loss and accidental deterioration of the goods sold is generally only transferred when the goods are handed over to the customer or a person authorized to receive them. Deviating from this, the risk of accidental loss and accidental deterioration of the goods sold, even for consumers, passes to the customer as soon as the seller has delivered the item to the freight forwarder, the freight carrier or the person or institution otherwise designated to carry out the shipment, if the The customer commissions the freight forwarder, the freight forwarder or the other person or institution designated to carry out the shipment to carry out the shipment and the seller has not previously named this person or institution to the customer.
5.4 The seller reserves the right to withdraw from the contract in the event of incorrect or improper delivery. This only applies in the event that the non-delivery is not the fault of the seller and the seller has concluded a specific cover transaction with the supplier with due care. The seller will make all reasonable efforts to procure the goods. In the event of non-availability or only partial availability of the goods, the customer will be informed immediately and the consideration will be refunded immediately.
5.5 Self-collection is not possible for logistical reasons.
5.6 Vouchers are provided to the customer as follows:
- by email
6) Retention of title
If the seller makes advance payments, he reserves ownership of the delivered goods until the purchase price owed has been paid in full.
7) Liability for defects (warranty)
7.1 Unless otherwise stated in the following regulations, the provisions of statutory liability for defects apply. Deviating from this, the following applies to contracts for the delivery of goods:
7.2 If the customer acts as an entrepreneur,
 • the seller has the choice of the type of supplementary performance;
 • For new goods, the limitation period for defects is one year from delivery of the goods;
 • In the case of used goods, rights and claims due to defects are excluded;
 • the statute of limitations does not begin again if a replacement delivery is made within the scope of liability for defects.
7.3 The limitations of liability and shortening of deadlines regulated above do not apply
 • to claims for damages and reimbursement of expenses by the customer,
 • in the event that the seller has fraudulently concealed the defect,
 • to goods that have been used for a building in accordance with their usual use and its defectiveness • for any existing
 obligation of the seller to provide updates for digital products, in contracts for the delivery of goods with digital elements.
7.4 Furthermore, for entrepreneurs, the statutory limitation periods for any existing legal recourse claim remain unaffected.
7.5 If the customer acts as a merchant within the meaning of § 1 HGB, he is subject to the commercial obligation to investigate and report complaints in accordance with § 377 HGB.

If the customer fails to comply with the reporting obligations regulated there, the goods are deemed to have been approved.
7.6 If the customer acts as a consumer, he is asked to complain to the deliverer about delivered goods with obvious transport damage and to inform the seller of this. If the customer does not comply with this, this will have no impact on his legal or contractual claims for defects.
8) Redemption of promotional vouchers
8.1 Vouchers that are issued free of charge by the seller as part of promotions with a specific period of validity and which cannot be purchased by the customer (hereinafter "promotional vouchers") can only be redeemed in the seller's online shop and only in the specified one period.
8.2 Promotional vouchers can only be redeemed by consumers.
8.3 Individual products may be excluded from the voucher campaign if a corresponding restriction results from the content of the campaign voucher.
8.4 Promotional vouchers can only be redeemed before completing the ordering process. Subsequent billing is not possible.
8.5 Only one promotional voucher can be redeemed per order.
8.6 The value of the goods must be at least equal to the amount of the promotional voucher. Any remaining balance will not be refunded by the seller.
8.7 If the value of the promotional voucher is not sufficient to cover the order, one of the other payment methods offered by the seller can be chosen to pay the difference.
8.8 The balance of a promotional voucher will neither be paid out in cash nor interest.
8.9 The promotional voucher will not be refunded if the customer returns the goods paid for in whole or in part with the promotional voucher within the scope of his statutory right of withdrawal.
8.10 The promotional voucher is transferable. The seller can make payments with discharging effect to the respective holder who redeems the promotional voucher in the seller's online shop. This does not apply if the seller has knowledge or grossly negligent ignorance of the lack of authorization, incapacity or lack of authorization to represent the respective owner.
9) Redemption of gift vouchers
9.1 Vouchers that can be purchased via the seller's online shop (hereinafter "gift vouchers") can only be redeemed in the seller's online shop, unless the voucher states otherwise.
9.2 Gift vouchers and remaining balance of gift vouchers can be redeemed until the end of the third year following the year in which the voucher was purchased. Remaining credit will be credited to the customer until the expiry date.
9.3 Gift vouchers can only be redeemed before completing the ordering process. Subsequent billing is not possible.
9.4 Multiple gift vouchers can also be redeemed with one order.
9.5 Gift vouchers can only be used to purchase goods and not to purchase additional gift vouchers.
9.6 If the value of the gift voucher is not sufficient to cover the order, one of the other payment methods offered by the seller can be chosen to settle the difference.
9.7 The balance of a gift voucher will neither be paid out in cash nor interest.
9.8 The gift voucher is transferable. The seller can make payments with discharging effect to the respective holder who redeems the gift voucher in the seller's online shop. This does not apply if the seller has knowledge or grossly negligent ignorance of the lack of authorization, incapacity or lack of authorization to represent the respective owner.
10) Applicable law
10.1 The law of the Federal Republic of Germany applies to all legal relationships between the parties, excluding the laws on the international purchase of movable goods. 09:55 PM
For consumers, this choice of law only applies to the extent that the protection granted is not withdrawn by mandatory provisions of the law of the country in which the consumer has his or her habitual residence.
10.2 Furthermore, this choice of law with regard to the statutory right of withdrawal does not apply to consumers who do not belong to a member state of the European Union at the time the contract is concluded and whose sole place of residence and delivery address is outside the European Union at the time the contract is concluded.
11) Place of jurisdiction
If the customer acts as a merchant, a legal entity under public law or a special fund under public law with its registered office in the Federal Republic of Germany, the exclusive place of jurisdiction for all disputes arising from this contract is the seller's place of business. If the customer is based outside the territory of the Federal Republic of Germany, the seller's place of business is the exclusive place of jurisdiction for all disputes arising from this contract if the contract or claims arising from the contract can be attributed to the customer's professional or commercial activity. In the above cases, however, the seller is in any case entitled to appeal to the court at the customer's registered office.
12) Alternative dispute resolution
12.1 The EU Commission provides a platform for online dispute resolution on the Internet under the following link: https://ec.europa.eu/consumers/odr
This platform serves as a contact point for the out-of-court settlement of disputes arising from online purchases - or service contracts involving a consumer.
12.2 The seller is neither obliged nor willing to take part in a dispute resolution procedure before a consumer arbitration board. 09:55 PM                """,
                style: TextStyle(
                    fontWeight: FontWeight.w400,
                    fontSize: 12,
                    color: Colors.grey.shade500),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
