import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import 'package:simp_token_app/customwidgets/locale.dart';
import 'package:simp_token_app/models/address_model.dart';
import 'package:simp_token_app/models/user_model.dart';
import 'package:simp_token_app/providers/user_provider.dart';
import 'package:simp_token_app/utils/sizedboxes.dart';
import 'package:simp_token_app/utils/theme.dart';
import 'package:simp_token_app/utils/widget_functions.dart';

class UserProfilePage extends StatelessWidget {
  const UserProfilePage({Key? key}) : super(key: key);
  static const String routeName = '/userprofile';

  @override
  Widget build(BuildContext context) {
    final localization = Provider.of<MyLocalization>(context);
    final userProvider = Provider.of<UserProvider>(context, listen: true);
    userProvider.init();

    return Scaffold(
      body: userProvider.userModel == null
          ? Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.person,
                    size: 90,
                    color: SimpTokenColorTheme().primaryColor,
                  ),
                  const SizedBox(height: 16),
                  Text(
                    "Anonymous",
                    style: Theme.of(context).textTheme.headline6,
                  ),
                ],
              ),
            )
          : ListView(
              children: [
                _headerSection(context, userProvider),
                ListTile(
                  leading: const Icon(Icons.call),
                  title: Text(
                    localization.translate("phone_number"),
                  ),
                  subtitle:
                      Text(userProvider.userModel!.phone ?? 'Not set yet'),
                  trailing: IconButton(
                    onPressed: () {
                      showSingleTextFieldInputDialog(
                          keyboardType: TextInputType.phone,
                          context: context,
                          title: localization.translate("mobile_number"),
                          onSubmit: (value) {
                            Provider.of<UserProvider>(context, listen: false)
                                .updateUserProfileField(userFieldPhone, value);
                          
                          });
                    },
                    icon: const Icon(Icons.edit),
                  ),
                ),
                ListTile(
                  leading: const Icon(Icons.location_on),
                  subtitle: Text(
                      userProvider.userModel!.addressModel?.addressLine1 ??
                          'Not set yet'),
                  title: Text(
                    localization.translate("address_line_1"),
                  ),
                  trailing: IconButton(
                    onPressed: () {
                      showSingleTextFieldInputDialog(
                        context: context,
                        title: localization.translate("address_line_1"),
                        onSubmit: (value) {
                          userProvider.updateUserProfileField(
                              '$userFieldAddressModel.$addressFieldAddressLine1',
                              value);
                        },
                      );
                    },
                    icon: const Icon(Icons.edit),
                  ),
                ),
                ListTile(
                  leading: const Icon(Icons.location_on),
                  subtitle: Text(
                      userProvider.userModel!.addressModel?.addressLine2 ??
                          'Not set yet'),
                  title: Text(
                    localization.translate("address_line_2"),
                  ),
                  trailing: IconButton(
                    onPressed: () {
                      showSingleTextFieldInputDialog(
                        context: context,
                        title: localization.translate("address_line_2"),
                        onSubmit: (value) {
                          userProvider.updateUserProfileField(
                              '$userFieldAddressModel.$addressFieldAddressLine2',
                              value);
                        },
                      );
                    },
                    icon: const Icon(Icons.edit),
                  ),
                ),
                ListTile(
                  leading: const Icon(Icons.location_city),
                  title: Text(userProvider.userModel!.addressModel?.city ??
                      'Not set yet'),
                  subtitle: Text(
                    localization.translate("city"),
                  ),
                ),
                ListTile(
                  leading: const Icon(Icons.location_city),
                  subtitle: Text(
                      userProvider.userModel!.addressModel?.zipcode ??
                          'Not set yet'),
                  title: Text(
                    localization.translate("set_zip_code"),
                  ),
                  trailing: IconButton(
                    onPressed: () {
                      showSingleTextFieldInputDialog(
                        context: context,
                        title: localization.translate("set_zip_code"),
                        keyboardType: TextInputType.number,
                        onSubmit: (value) {
                          userProvider.updateUserProfileField(
                              '$userFieldAddressModel.$addressFieldZipcode',
                              value);
                        },
                      );
                    },
                    icon: const Icon(Icons.edit),
                  ),
                ),
              ],
            ),
    );
  }

  Container _headerSection(BuildContext context, UserProvider userProvider) {
    print("=====------->>> ${userProvider.userModel!.imageUrl!}");
    return Container(
      height: MediaQuery.of(context).size.height * 0.22,
      color: SimpTokenColorTheme().primaryColor,
      child: GestureDetector(
        onTap: () {
          // Handle the tap on the image to initiate the image upload process.
          getImage(context, userProvider);
        },
        child: Row(
          children: [
            SizedBoxes.horizontalBig,
            Card(
              elevation: 12,
              child: userProvider.userModel!.imageUrl == null
                  ? Icon(
                      Icons.person,
                      size: 90,
                      color: SimpTokenColorTheme().primaryColor,
                    )
                  : CachedNetworkImage(
                      width: 90,
                      height: 90,
                      imageUrl: userProvider.userModel!.imageUrl!,
                      placeholder: (context, url) => const Center(
                        child: CircularProgressIndicator(),
                      ),
                      errorWidget: (context, url, error) =>
                          const Icon(Icons.error),
                    ),
            ),
            const SizedBox(
              width: 15,
            ),
            Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  userProvider.userModel!.displayName ?? 'No Display Name',
                  style: Theme.of(context)
                      .textTheme
                      .headline6!
                      .copyWith(color: Colors.white),
                ),
                Text(
                  userProvider.userModel!.email,
                  style: const TextStyle(color: Colors.white60),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  void getImage(BuildContext context, UserProvider userProvider) async {
    final imagePicker = ImagePicker();
    final pickedFile = await imagePicker.pickImage(source: ImageSource.gallery);

    if (pickedFile != null) {
      userProvider.updateUserProfileField(
          '$userFieldImageUrl', pickedFile.path);

      // Update the selectedImage variable
      userProvider.selectedImage = pickedFile.path;

      await userProvider.updateUserImageInFirestore(pickedFile.path);
    }
  }
}
