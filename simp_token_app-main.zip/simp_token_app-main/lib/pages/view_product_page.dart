import 'dart:math';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_image_slideshow/flutter_image_slideshow.dart';
import 'package:provider/provider.dart';
import 'package:simp_token_app/providers/nav_bar_controller.dart';
import 'package:simp_token_app/utils/image_constants.dart';
import 'package:simp_token_app/utils/sizedboxes.dart';
import 'package:simp_token_app/utils/theme.dart';
import '../providers/product_provider.dart';

class ViewProductPage extends StatefulWidget {
  static const String routeName = '/viewproduct';

  const ViewProductPage({Key? key}) : super(key: key);

  @override
  State<ViewProductPage> createState() => _ViewProductPageState();
}

class _ViewProductPageState extends State<ViewProductPage> {
  @override
  void didChangeDependencies() {
    Provider.of<ProductProvider>(context, listen: false).getAllCategories();
    Provider.of<ProductProvider>(context, listen: false).getAllProducts();
    Provider.of<ProductProvider>(context, listen: false).getAllPurchases();
    super.didChangeDependencies();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: CustomScrollView(
        slivers: [
          SliverToBoxAdapter(
            child: AspectRatio(
              aspectRatio: 16 / 9,
              child: ImageSlideshow(
                width: double.infinity,
                height: double.infinity,
                children: [
                  Image.asset(
                    AppConstants.appLogo1,
                    fit: BoxFit.contain,
                  ),
                  Image.asset(
                    AppConstants.appLogo2,
                    fit: BoxFit.contain,
                  ),
                ],
              ),
            ),
          ),
          Consumer<ProductProvider>(
            builder: (context, provider, child) {
              final categories = provider.getCategoriesForFiltering();
              return SliverList(
                delegate: SliverChildBuilderDelegate(
                  (context, index) {
                    final category = categories[index];
                    final productsForCategory = provider.productList
                        .where((product) =>
                            category.categoryName == 'All' ||
                            product.category.categoryName ==
                                category.categoryName)
                        .toList();

                    final randomIndex = productsForCategory.isNotEmpty
                        ? Random().nextInt(productsForCategory.length)
                        : 0;

                    final randomImageUrl = productsForCategory.isNotEmpty
                        ? productsForCategory[randomIndex]
                            .thumbnailImageModel
                            .imageDownloadUrl
                        : '';

                    return Card(
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(15.0),
                      ),
                      color: SimpTokenColorTheme().logoColor,
                      elevation: 12,
                      margin: const EdgeInsets.only(
                          top: 10, bottom: 12, left: 15, right: 15),
                      child: InkWell(
                        onTap: () {
                          final bottomNavBarController =
                              Provider.of<BottomNavBarController>(context,
                                  listen: false);
                          bottomNavBarController.changeScreen(1,
                              additionalData: category);
                        },
                        child: Column(
                          children: [
                            ClipRRect(
                              borderRadius: const BorderRadius.only(
                                  topLeft: Radius.circular(15.0),
                                  topRight: Radius.circular(15.0)),
                              child: Image.network(
                                randomImageUrl,
                                width: double.infinity,
                                // height: 120,
                                fit: BoxFit.contain,
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Text(
                                category.categoryName,
                                style: TextStyle(
                                    fontSize: 18,
                                    fontWeight: FontWeight.bold,
                                    color: SimpTokenColorTheme().white),
                              ),
                            ),
                            Text(
                              '${productsForCategory.length} items available',
                              style: TextStyle(
                                  fontSize: 14,
                                  fontWeight: FontWeight.bold,
                                  color: SimpTokenColorTheme().white),
                            ),
                            SizedBoxes.verticalBig
                          ],
                        ),
                      ),
                    );
                  },
                  childCount: categories.length,
                ),
              );
            },
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(40)),
        backgroundColor: SimpTokenColorTheme().primarygolden,
        onPressed: () {
          Navigator.pushNamed(context, '/chatpage');
        },
        child: Icon(
          CupertinoIcons.chat_bubble_2_fill,
          color: SimpTokenColorTheme().white,
        ),
      ),
    );
  }
}
