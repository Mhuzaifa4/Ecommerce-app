import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:simp_token_app/auth/auth_service.dart';
import 'package:simp_token_app/customwidgets/locale.dart';
import 'package:simp_token_app/customwidgets/reusable_btn.dart';
import 'package:simp_token_app/pages/launcher_page.dart';
import 'package:simp_token_app/pages/login_page.dart';
import 'package:simp_token_app/utils/image_constants.dart';

class WelcomePage extends StatelessWidget {
  static const String routeName = '/welcomepage';

  const WelcomePage({super.key});

  @override
  Widget build(BuildContext context) {
    final localization = Provider.of<MyLocalization>(context);

    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20),
        child: Scaffold(
          body: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Spacer(),
              Center(
                  child: Image.asset(
                AppConstants.appLogo2,
                height: 200,
              )),
              Spacer(),
              ReUsableButton(
                title: localization.translate("login"),
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => LoginPage()),
                  );
                },
              ),
              const SizedBox(height: 20),
              ReUsableButton(
                title: localization.translate("login_as_guest"),
                onTap: () {
                  _loginAsGuest(context);
                },
              ),
              const SizedBox(height: 60),
              _buildLanguageDropdown(context),
              const SizedBox(height: 40),
            ],
          ),
        ),
      ),
    );
  }

  void _loginAsGuest(BuildContext context) async {
    try {
      await AuthService.signInAnonymously();
      Navigator.pushReplacementNamed(context, LauncherPage.routeName);
    } catch (error) {
      print("Error during anonymous login: $error");
    }
  }
}

Widget _buildLanguageDropdown(BuildContext context) {
  final localization = Provider.of<MyLocalization>(context);

  return DropdownButton<String>(
    value: localization.languageCode,
    items: [
      DropdownMenuItem(
        value: 'en',
        child: Text('English'),
      ),
      DropdownMenuItem(
        value: 'de',
        child: Text('Deutsch'),
      ),
    ],
    onChanged: (String? newValue) {
      if (newValue != null) {
        localization.setLocale(newValue);
      }
    },
  );
}
