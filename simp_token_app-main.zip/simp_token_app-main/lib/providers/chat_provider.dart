import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ChatProvider extends ChangeNotifier {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  late User _currentUser;
  late CollectionReference _userMessages;
  late CollectionReference _adminMessages;

  final List<Message> _messages = [];

  List<Message> get messages => _messages;

  static const String _welcomeMessageKey = 'welcomeMessageSent';

  bool _initialized = false;

  ChatProvider() {
    print("======---->>> ${_messages}");
    // Call the initialization method only if not already initialized
    if (!_initialized) {
      initialize();
    }
  }

  Future<void> initialize() async {
    if (_initialized) {
      return;
    }

    print('Initializing ChatProvider');
    _currentUser = _auth.currentUser!;
    _userMessages = _firestore
        .collection('chat')
        .doc(_currentUser.uid)
        .collection('user_messages');
    _adminMessages =
        _firestore.collection('chat').doc('admin').collection('admin_messages');

    bool welcomeMessageSent = await _getWelcomeMessageFlag();
    print('Welcome message sent: $welcomeMessageSent');

    if (!welcomeMessageSent) {
      print('Sending welcome message...');
      _adminMessages.add({
        'text': 'Hello! How can I help you?',
        'senderId': 'admin',
        'timestamp': FieldValue.serverTimestamp(),
      });

      // Update the flag only if the message is successfully sent
      await _setWelcomeMessageFlag();
    }

    _userMessages.snapshots().listen(
      (userSnapshot) {
        if (userSnapshot.docs.isNotEmpty) {
          _processUserMessages(
              userSnapshot as QuerySnapshot<Map<String, dynamic>>);
        }
      },
      onError: (error) {
        print('Error processing user messages: $error');
      },
    );

    _adminMessages.snapshots().listen((adminSnapshot) {
      print('Admin messages snapshot received');
      if (adminSnapshot.docs.isNotEmpty) {
        _processAdminMessages(
          adminSnapshot as QuerySnapshot<Map<String, dynamic>>,
        );
      }
    }, onError: (error) {
      print('Error processing admin messages: $error');
    });

    _initialized = true;
  }

  Future<bool> _getWelcomeMessageFlag() async {
    try {
      SharedPreferences prefs = await SharedPreferences.getInstance();
      return prefs.getBool(_welcomeMessageKey) ?? false;
    } catch (e) {
      print('Error retrieving welcome message flag: $e');
      return false;
    }
  }

  Future<void> _setWelcomeMessageFlag() async {
    print('Setting welcome message flag');
    SharedPreferences prefs = await SharedPreferences.getInstance();
    prefs.setBool(_welcomeMessageKey, true);
  }

  void _processUserMessages(QuerySnapshot<Map<String, dynamic>> userSnapshot) {
    _updateMessages(userSnapshot, isUser: true);
  }

  void _processAdminMessages(
      QuerySnapshot<Map<String, dynamic>> adminSnapshot) {
    _updateMessages(adminSnapshot, isUser: false);
  }

  void _updateMessages(QuerySnapshot<Map<String, dynamic>> snapshot,
      {required bool isUser}) {
    final List<Message> newMessages = snapshot.docs
        .map(
          (doc) {
            final data = doc.data();
            return Message(
              text: data['text'] ?? '',
              isMe: isUser ? data['senderId'] == _currentUser.uid : false,
            );
          },
        )
        .toList()
        .reversed
        .toList();

    // Check if the welcome message already exists in the list
    final bool containsWelcomeMessage = newMessages
        .any((message) => message.text == 'Hello! How can I help you?');

    // Only add new messages if the welcome message is not already in the list
    if (!containsWelcomeMessage) {
      _messages.clear();
      _messages.addAll(newMessages);
      notifyListeners();
    }
  }

  void sendMessage(String text) async {
    final message = Message(text: text, isMe: true);
    _userMessages.add({
      'text': message.text,
      'senderId': _currentUser.uid,
      'timestamp': FieldValue.serverTimestamp(),
    });
  }
}

class Message {
  final String text;
  final bool isMe;

  Message({required this.text, required this.isMe});
}
