import 'package:flutter/material.dart';
import 'package:simp_token_app/models/product_model.dart';

class FavouriteProvider with ChangeNotifier {
  Set<ProductModel> favoriteProducts = {};

  bool isProductInFavorites(ProductModel product) {
    return favoriteProducts.contains(product);
  }

  void addToFavorites(ProductModel product) {
    favoriteProducts.add(product);
    notifyListeners();
  }

  void removeFromFavorites(ProductModel product) {
    favoriteProducts.remove(product);
    notifyListeners();
  }
}
