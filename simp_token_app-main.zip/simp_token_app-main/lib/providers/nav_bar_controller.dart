import 'package:flutter/material.dart';
import 'package:simp_token_app/pages/favourite_page.dart';
import 'package:simp_token_app/pages/order_page.dart';
import 'package:simp_token_app/pages/shop_page.dart';
import 'package:simp_token_app/pages/user_profile_page.dart';
import 'package:simp_token_app/pages/view_product_page.dart';

class BottomNavBarController extends ChangeNotifier {
  int _currentIndex = 0;

  int get currentIndex => _currentIndex;

  Widget _currentScreen = ViewProductPage();

  Widget get currentScreen => _currentScreen;

  void changeScreen(int index, {dynamic additionalData}) {
    _currentIndex = index;
    switch (index) {
      case 0:
        _currentScreen = ViewProductPage();
        break;
      case 1:
        _currentScreen = ShopPage(selectedCategory: additionalData);
        break;
      case 2:
        _currentScreen = FavouritePage();
        break;
      case 3:
        _currentScreen = OrderPage();
        break;
      case 4:
        _currentScreen = UserProfilePage();
        break;
      default:
        break;
    }

    notifyListeners();
  }
}
