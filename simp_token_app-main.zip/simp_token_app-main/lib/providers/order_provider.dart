import 'package:flutter/material.dart';
import 'package:simp_token_app/auth/auth_service.dart';
import 'package:simp_token_app/models/notification_model.dart';
import 'package:simp_token_app/models/order_item_model.dart';
import 'package:simp_token_app/models/order_model.dart';
import '../db/db_helper.dart';

class OrderProvider extends ChangeNotifier {
  List<OrderModel> orderList = [];
  List<OrderItem> orderItemList = [];

  Color getOrderStatusColor(String orderStatus) {
    switch (orderStatus.toLowerCase()) {
      case 'pending':
        return Colors.red;

      case 'approved':
        return Colors.green;

      case 'cancelled':
        return Colors.red;

      default:
        return Colors.black;
    }
  }

  getOrderConstants() {
    DbHelper.getOrderConstants().listen((snapshot) {
      if (snapshot.exists) {
        notifyListeners();
      }
    });
  }

  getOrdersByUser() {
    DbHelper.getOrdersByUser(AuthService.currentUser!.uid).listen((snapshot) {
      print("====---->>${AuthService.currentUser!.uid}");

      if (snapshot.docs.isNotEmpty) {
        print("====---->>${AuthService.currentUser!.uid}");
        orderList = List.generate(snapshot.docs.length,
            (index) => OrderModel.fromMap(snapshot.docs[index].data()));
        orderItemList =
            orderList.map((order) => OrderItem(orderModel: order)).toList();
        notifyListeners();
        print('Order List Length: ${orderList.length}');
      } else {
        print("====---->>${AuthService.currentUser!.uid}");

        print('No orders found for the user.');
      }
    });
  }

  int getGrandTotal(num cartSubTotal) {
    return ((cartSubTotal)).round();
  }

  Future<void> saveOrder(OrderModel orderModel) async {
    await DbHelper.saveOrder(orderModel);
    return DbHelper.clearCart(orderModel.userId, orderModel.productDetails);
  }

  Future<void> sendProductApprovalNotification(String productId) async {
    String message = 'Your product with ID $productId has been approved.';
    NotificationModel notification = NotificationModel(
      id: productId,
      type: 'product_approval',
      message: message,
    );
    await addNotification(notification);
    notifyListeners();
  }

  Future<void> addNotification(NotificationModel notification) {
    return DbHelper.addNotification(notification);
  }
}
