import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:simp_token_app/auth/auth_service.dart';
import 'package:simp_token_app/db/db_helper.dart';
import 'package:simp_token_app/models/user_model.dart';

class UserProvider extends ChangeNotifier {
  UserModel? userModel;
  String? selectedImage; // Add this variable to store the selected image path

  Future<void> addUser(UserModel userModel) => DbHelper.addUser(userModel);

  Future<bool> doesUserExist(String uid) => DbHelper.doesUserExist(uid);

  Future<void> init() async {
    await Future.delayed(Duration(seconds: 1));
    await getUserInfo();
  }

  Future<void> updateUserImageInFirestore(String imageUrl) async {
    try {
      final userUid = AuthService.currentUser!.uid;
      final userDocRef =
          FirebaseFirestore.instance.collection('User').doc(userUid);

      // Upload the image to Firebase Storage
      final storageRef = FirebaseStorage.instance
          .ref()
          .child('user_images')
          .child('$userUid.jpg');
      await storageRef.putFile(File(imageUrl));

      // Get the download URL
      final downloadUrl = await storageRef.getDownloadURL();

      // Update the user document in Firestore with the download URL
      await userDocRef.update({
        'imageUrl': downloadUrl,
      });

      selectedImage = downloadUrl;

      if (userModel != null) {
        userModel!.imageUrl = downloadUrl;
      }

      notifyListeners();
    } catch (error) {
      print('Error updating user image in Firestore: $error');
    }
  }

  getUserInfo() {
    if (AuthService.currentUser != null) {
      print("Getting user info for: ${AuthService.currentUser!.uid}");
      DbHelper.getUserInfo(AuthService.currentUser!.uid).listen((snapshot) {
        if (snapshot.exists) {
          userModel = UserModel.fromMap(snapshot.data()!);
          notifyListeners();
          print("User model set: $userModel");
        } else {
          print("User document does not exist");
        }
      });
    }
  }

  Future<void> updateUserProfileField(String field, dynamic value) {
    return DbHelper.updateUserProfileField(
        AuthService.currentUser!.uid, {field: value});
  }

  // addNotification(NotificationModel notification) {
  //   return DbHelper.addNotification(notification);
  // }
}
