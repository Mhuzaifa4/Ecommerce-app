const String firebaseStorageProductImageDir = 'ProductImages';
const String currencySymbol = '\$';

abstract class OrderStatus {
  static const String pending = 'Pending';
  static const String delivered = 'Approved';
  static const String cancelled = 'Cancelled';
}

abstract class PaymentMethod {
  static const String cod = 'Cash on Delivery';
  static const String online = 'Online Payment';
}

abstract class NotificationType {
  static const String order = 'New Order';
}

const cities = [
  'Karachi',
  'Lahore',
  'Faisalabad',
  'Rawalpindi',
  'Multan',
  'Peshawar',
  'Quetta',
  'Islamabad',
  'Sialkot',
  'Gujranwala',
  'Hyderabad',
];
