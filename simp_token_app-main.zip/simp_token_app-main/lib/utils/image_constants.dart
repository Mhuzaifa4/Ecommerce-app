abstract class AppConstants {
  static const appLogo1 = 'assets/applogo/applogo1.png';
  static const appLogo2 = 'assets/applogo/applogo2.png';
}
