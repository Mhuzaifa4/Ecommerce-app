import 'package:flutter/material.dart';

class SimpTokenColorTheme {
  Color get primarygolden => const Color(0xFfc0edff);
  Color get primaryColor => const Color(0xFFefbaac);
  Color get primaryButtonColor => Color.fromARGB(255, 217, 62, 18);
  Color get logoColor => const Color(0xFFf3e565);
  Color get secondaryColor => const Color(0xFFeae3d7);
  Color get red => Colors.red;

  //normal color list
  Color get white => const Color(0xFFFFFFFF);
  Color get black => const Color(0xFF000000);
}
